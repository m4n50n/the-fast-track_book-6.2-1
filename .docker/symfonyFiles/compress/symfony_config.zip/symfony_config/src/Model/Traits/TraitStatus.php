<?php

namespace App\Model\Traits;

use Doctrine\ORM\Mapping as ORM;

/**
 * Trait status for standar entities
 * @author DigitalVirgo España
 */
trait TraitStatus
{
    /**
     * @var string $status
     * @ORM\Column(name="status", type="string", length=100, nullable=true)
     */
    #[ORM\Column(name:"status", type: 'string', length: 100, nullable:true)]
    private $status = null;

    /**
     * @var string $subStatus
     * @ORM\Column(name="sub_status", type="string", length=100, nullable=true)
     */
    #[ORM\Column(name:"sub_status", type: 'string', length: 100, nullable:true)]
    private $subStatus = null;

    /**
     * Get status
     * @return string
     */
    public function getStatus(): ?string
    {
        return $this->status;
    }

    /**
     * Set status
     * @param string $status
     */
    public function setStatus(string $status): self
    {
        $this->status = $status;
        return $this;
    }

    /**
     * Get subStatus
     * @return string
     */
    public function getSubStatus(): ?string
    {
        return $this->subStatus;
    }

    /**
     * Set subStatus
     * @param string $subStatus
     */
    public function setSubStatus(?string $subStatus): self
    {
        $this->subStatus = $subStatus;
        return $this;
    }
}