<?php

namespace App\Model\Traits;

use DateTime;
use Exception;

use Doctrine\ORM\EntityManagerInterface;
use Doctrine\ORM\PersistentCollection;
use Symfony\Bridge\Doctrine\PropertyInfo\DoctrineExtractor;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\PropertyInfo\Extractor\ReflectionExtractor;
use Symfony\Component\PropertyInfo\PropertyInfoExtractor;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Psr\Log\LoggerInterface;

use App\Entity\EventLog;
use App\Entity\User;
use App\Model\EntitiesCRUD\EventLogCRUD;
use phpDocumentor\Reflection\Types\Boolean;
use Symfony\Component\Serializer\Encoder\JsonEncoder;
use Symfony\Component\Serializer\Encoder\XmlEncoder;
use Symfony\Component\Serializer\Normalizer\ObjectNormalizer;
use Symfony\Component\Serializer\Serializer;

/**
 * model for the CRUD actions of the general CRUD models
 * @author DigitalVirgo España
 */
trait TraitGeneralCRUD
{
    // Respuesta estandar
    use TraitResponse;

    /**
     *                      _                   _              _____       _ _   
     *                     | |                 | |     ___    |_   _|     (_) |  
     *   ___ ___  _ __  ___| |_ _ __ _   _  ___| |_   ( _ )     | |  _ __  _| |_ 
     *  / __/ _ \| '_ \/ __| __| '__| | | |/ __| __|  / _ \/\   | | | '_ \| | __|
     * | (_| (_) | | | \__ \ |_| |  | |_| | (__| |_  | (_>  <  _| |_| | | | | |_ 
     *  \___\___/|_| |_|___/\__|_|   \__,_|\___|\__|  \___/\/ |_____|_| |_|_|\__|
     */

    private $client;

    protected $doctrine;
    public function setDoctrine($doctrine)
    {
        $this->doctrine = $doctrine;
        return $this;
    }
    protected $entityManager;
    protected $logger;
    protected $containerInterface;
    protected $serializer;

    /** Contructor of the class */
    public function __construct($entityManager, LoggerInterface $logger, User $thisUser = null)
    {
        $this->doctrine = ( !$entityManager instanceof EntityManagerInterface ) ? $entityManager : null;
        $this->entityManager = ( $entityManager instanceof EntityManagerInterface ) ? $entityManager : $this->doctrine->getManager();
        $this->logger = $logger;
        $this->containerInterface = null;
        $this->initCRUD();
        
        ### https://symfony.com/doc/current/components/serializer.html
        $encoders = [new XmlEncoder(), new JsonEncoder()];
        $normalizers = [new ObjectNormalizer()];
        $this->serializer = new Serializer($normalizers, $encoders);

        // this user
        if ( $thisUser != null ) {
            $this->setThisUser( $thisUser );
        }
    }

    /** Contructor0 of the class OLD_method */
    public function __construct0($entityManager, ContainerInterface $containerInterface, Object $model = null, array $arrExcludeNorm = null ) 
    {
        $this->doctrine = (!$entityManager instanceof EntityManagerInterface) ? $entityManager : null;
        $this->entityManager = ($entityManager instanceof EntityManagerInterface) ? $entityManager : $this->doctrine->getManager();
        $this->containerInterface = $containerInterface;
        $this->logger = null;
        $this->initCRUD();
    }

    /**
     * General initializeCRUD. this will be init personalized for the classes
     */
    public function initCRUD()
    {
        // // example for user
        // $this->setRequiredParams( ['username', 'email', 'password'] );
        // $this->setUniqueParams( ['username', 'email'] );
        // $this->setAdviseParams( ['language'] );
        // $this->excludeNorm = ['eventLogs'];

        // The name of the method in the key, the param in the value
        // $this->setMethodsToValidateCreate( [ 'validateDataInMethod' => null ] );
        // $this->setMethodsProcessProperties( [ 'processPropertiesInMethod' => null ] );
    }

    /** Method to set debug */
    private function setDebug( String $dataToDebug, String $type = 'info' ) {

        if ( $this->containerInterface != null ) {
            $this->containerInterface->get('logger')->$type( $dataToDebug );
        } else {
            $this->logger->$type( $dataToDebug );
        }

    }

    /**
     *                      _      _ _____        _        
     *                     | |    | |  __ \      | |       
     *  _ __ ___   ___   __| | ___| | |  | | __ _| |_ __ _ 
     * | '_ ` _ \ / _ \ / _` |/ _ \ | |  | |/ _` | __/ _` |
     * | | | | | | (_) | (_| |  __/ | |__| | (_| | || (_| |
     * |_| |_| |_|\___/ \__,_|\___|_|_____/ \__,_|\__\__,_|
     *                                                     
     */

    /** MODEL */
    protected $model;
    public function getModel()
    {
        return $this->model;
    }
    public function setModel(Object $model)
    {
        $this->model = $model;
        return $this;
    }

    /** ModelName */
    protected $modelName = null;
    public function getModelName()
    {
        if ($this->modelName == null) {
            // $modelName = $this->entityManager->getClassMetadata(get_class($this->getModel()))->getName();
            $modelName = get_class($this->getModel());
            if (strpos($modelName, "App\\Entity\\") !== false) {
                $this->modelName = str_replace("App\\Entity\\", "", $modelName);
            } else {
                foreach (explode("\\", $modelName) as $value) {
                    $this->modelName = $value;
                }
            }
        }
        return $this->modelName;
    }
    // public function setModelName(String $modelName) {
    //     $this->modelName = $modelName;
    //     return $this;
    // }

    /** Get array properties of model */
    // protected $reflectionClass;
    protected $arrProperties = [];
    public function getModelProperties(Object $object = null)
    {
        // debug
        // $this->containerInterface->get('logger')->info('Init method: ' .  __FUNCTION__);
        $object_ = ($object != null) ? $object : (($this->model != null) ? $this->model : null);
        if ($object_ != null) {
            $reflectionExtractor = new ReflectionExtractor();
            $doctrineExtractor = new DoctrineExtractor($this->entityManager);
            $propertyInfo = new PropertyInfoExtractor(
                // List extractors
                [$reflectionExtractor, $doctrineExtractor],
                // Type extractors
                [$reflectionExtractor, $doctrineExtractor]
            );
            $this->arrProperties = $propertyInfo->getProperties(get_class($object_));
        }
        return $this->arrProperties;
    }
    /** Old method for getModelProperties */
    public function getArrProperties(Object $object = null)
    {
        return $this->getModelProperties($object);
    }

    /** Get array methods of model */
    protected $arrMethods = [];
    public function getModelMethods(Object $object = null)
    {
        $object_ = ($object !== null) ? $object : (($this->model !== null) ? $this->model : null);
        if ($object_ !== null) {
            try {
                $this->arrMethods = get_class_methods($object_);
            } catch (Exception $ex) {
                $this->arrMethods = null;
            }
        }
        // $this->containerInterface->get('logger')->info(json_encode([__FUNCTION__ => $this->arrMethods]));
        return $this->arrMethods;
    }
    /** Old method for getModelMethods */
    public function getArrMethods(Object $object = null)
    {
        return $this->getModelMethods($object);
    }

    /**
     *                   __ _          _____ _____  _    _ _____  
     *                  / _(_)        / ____|  __ \| |  | |  __ \ 
     *   ___ ___  _ __ | |_ _  __ _  | |    | |__) | |  | | |  | |
     *  / __/ _ \| '_ \|  _| |/ _` | | |    |  _  /| |  | | |  | |
     * | (_| (_) | | | | | | | (_| | | |____| | \ \| |__| | |__| |
     *  \___\___/|_| |_|_| |_|\__, |  \_____|_|  \_\\____/|_____/ 
     *                         __/ |                              
     *                        |___/                               
     */

    /** Params recomended to exist in object */
    protected $adviseParams = [];
    public function getAdviseParams()
    {
        return $this->adviseParams;
    }
    public function setAdviseParams(array $adviseParams)
    {
        $this->adviseParams = $adviseParams;
        return $this;
    }
    public function addAdviseParam(String $adviseParam)
    {
        if (!in_array($adviseParam, $this->adviseParams)) {
            $this->adviseParams[] = $adviseParam;
        }
        return $this;
    }

    /** Params required to exist in object */
    protected $requiredParams = [];
    public function getRequiredParams()
    {
        return $this->requiredParams;
    }
    public function setRequiredParams(array $requiredParams)
    {
        $this->requiredParams = $requiredParams;
        return $this;
    }
    public function addRequiredParam(String $requiredParam)
    {
        if (!in_array($requiredParam, $this->requiredParams)) {
            $this->requiredParams[] = $requiredParam;
        }
        return $this;
    }

    /** Params uniques in object */
    protected $uniqueParams = [];
    public function getUniqueParams()
    {
        return $this->uniqueParams;
    }
    public function setUniqueParams(array $uniqueParams)
    {
        $this->uniqueParams = $uniqueParams;
        return $this;
    }
    public function addUniqueParam(String $uniqueParam)
    {
        if (!in_array($uniqueParam, $this->uniqueParams)) {
            $this->uniqueParams[] = $uniqueParam;
        }
        return $this;
    }

    /** Params uniques and repeat in object */
    protected $groupUniqueParams = [];
    public function getGroupUniqueParams()
    {
        return $this->groupUniqueParams;
    }
    public function setGroupUniqueParams(array $groupUniqueParams)
    {
        $this->groupUniqueParams = $groupUniqueParams;
        return $this;
    }
    public function addGroupUniqueParam(String $groupUniqueParam)
    {
        if (!in_array($groupUniqueParam, $this->groupUniqueParams)) {
            $this->groupUniqueParams[] = $groupUniqueParam;
        }
        return $this;
    }

    /** Define if force or not registry eventLog */
    protected $forceEventLog = true;
    public function setForceEventLog(bool $forceEventLog = true)
    {
        $this->forceEventLog = ($forceEventLog) ? true : false;
        return $this;
    }
    protected $registerEventLog = true;
    public function setRegisterEventLog(bool $registerEventLog)
    {
        $this->registerEventLog = ($registerEventLog) ? true : false;
        $this->forceEventLog = $this->registerEventLog;
        return $this;
    }

    /**
     *             _   _                    _____ _____  _    _ _____  
     *            | | (_)                  / ____|  __ \| |  | |  __ \ 
     *   __ _  ___| |_ _  ___  _ __  ___  | |    | |__) | |  | | |  | |
     *  / _` |/ __| __| |/ _ \| '_ \/ __| | |    |  _  /| |  | | |  | |
     * | (_| | (__| |_| | (_) | | | \__ \ | |____| | \ \| |__| | |__| |
     *  \__,_|\___|\__|_|\___/|_| |_|___/  \_____|_|  \_\\____/|_____/ 
     *                                                                 
     *                                                                 
     */

    /** 
     * Standar method to create new register in Objects (C de CRUD)
     * @return Array the response value.
     */
    public function create(Request $request = null, ?array $arrProperties = null, Object $object_ = null): ?array
    {
        try {
            [$code, $error, $message, $data, $object] = [200, false, 'There is an error to ' . __FUNCTION__, [], []];
            $data['action'] = __FUNCTION__;
            $this->initializeResponse($code, $error, $message, $data, $object);            
            $this->setDebug( 'Init method: ' .  __FUNCTION__ );

            // Compose object from this data $request, $arrProperties or $object
            $this->setResponse($this->setValuesModel($request, $arrProperties, $object_));
            if (!$this->getError()) { // Error 1
                $data['values'] = $this->getData();

                $this->setResponse($this->validateDataToCreate($request, $arrProperties, $object_));
                if (!$this->getError()) { // Error 2
                    $data['validate'] = $this->getData();

                    // Registry valors
                    $this->entityManager->persist($this->model);
                    $this->entityManager->flush();

                    // validate action validateDataToUpdate == true
                    $data['id'] = ($this->existMethodInObject('getId')) ? $this->model->getId() : null;
                    // $data['objectNormalized'] = $this->normalizeObjectFull($this->getModel(), 1, $this->getModelName());
                    $data['objectNormalized'] = $this->serializer->serialize($this->getModel(), 'json');

                    // prepare response
                    $message = $this->getModelName() . " " . $data['action'];
                    [$code, $error, $message, $data, $object] = [201, false, $message, $data, $this->getModel()];

                } else { [$code, $error, $message, $data, $object] = $this->getResponse('unstructure'); } // Error 2
            } else { [$code, $error, $message, $data, $object] = $this->getResponse('unstructure'); } // error 1

            // set response
            $this->finalResponse($code, $error, $message, $data, $object);

            // eventLog if forced
            if ( $this->registerEventLog ) {
                [$code, $error, $message, $data, $object] = $this->getResponse('unstructure'); // backup responseValors
                $this->jsonDataNew = $this->serializer->normalize($this->getModel());

                $this->setResponse( $this->setEventLog(__FUNCTION__, $message) );
                $data['setEventLog'] = $this->getResponse('unstructure');
                $this->initializeResponse($code, $error, $message, $data, $object); // Reinit responseValors
            }

            // Set Response
            $this->finalResponse($code, $error, $message, $data, $object);
            $this->setDebug( 'Final method: ' .  __FUNCTION__ );

        } catch (Exception $ex) {
            $this->setCode(418);
            $this->setError(true);
            $this->setMessage("Error: {$ex->getMessage()} in class: " . __CLASS__ . ", method: " . __FUNCTION__ . ", file: " . __FILE__ . ", line: " . __LINE__ .
                " Object: " . $this->getModelName());
        }
        return $this->getResponse();
    }

    /** 
     * Standar method to update register in Objects (U de CRUD)
     * @return Array the response value.
     */
    public function update(Request $request = null, ?array $arrProperties = null, Object $object_ = null): ?array
    {
        try {
            $code = 400; $error = true; $message = 'There is an error to ' . __FUNCTION__ . ' method'; $data = []; $object = []; 
            $data['action'] = __FUNCTION__;
            $this->initializeResponse($code, $error, $message, $data, $object);
            $this->setDebug( 'Init method: ' .  __FUNCTION__ );

            // 1.- Search Object
            $this->setResponse($this->findObjectByUniqueParams($request, $arrProperties, $object_, 'update'));
            if (!$this->getError()) { // Error 1
                $data['validate'] = $this->getData();
                $this->setDebug( $this->serializer->serialize( $this->model, 'json' ) );

                // 2.- Update model with properties
                $this->setResponse($this->setValuesModel($request, $arrProperties, $object_));
                if (!$this->getError()) { // Error 2
                    $data['values'] = $this->getData();
                    $this->setDebug( $this->serializer->serialize( $this->model, 'json' ) );

                    // save valors
                    $this->entityManager->persist( $this->model );
                    // $this->entityManager->persist( $object );
                    $this->entityManager->flush();

                    // validate action validateDataToUpdate == true
                    $data['id'] = ($this->existMethodInObject('getId')) ? $this->model->getId() : null;
                    // $data['objectNormalized'] = $this->normalizeObjectFull($this->getModel(), 1, $this->getModelName());
                    $data['objectNormalized'] = $this->serializer->serialize($this->getModel(), 'json');

                    // prepare response
                    $message = $this->getModelName() . " " . $data['action'];
                    [$code, $error, $message, $data, $object] = [201, false, $message, $data, $this->getModel()];

                } else { [$code, $error, $message, $data, $object] = $this->getResponse('unstructure'); } // Error 2
            } else { [$code, $error, $message, $data, $object] = $this->getResponse('unstructure'); } // error 1

            $this->finalResponse($code, $error, $message, $data, $object);

            // eventLog if forced
            if ($this->registerEventLog) {
                [$code, $error, $message, $data, $object] = $this->getResponse('unstructure'); // backup responseValors
                $this->jsonDataNew = $this->serializer->normalize($this->getModel());

                $this->setResponse($this->setEventLog( __FUNCTION__, $message ));
                $data['setEventLog'] = $this->getResponse('unstructure');
                $this->initializeResponse($code, $error, $message, $data, $object); // Reinit responseValors
            }

            // Set Response
            $this->finalResponse($code, $error, $message, $data, $object);
            $this->setDebug( 'Final method: ' .  __FUNCTION__ );

        } catch (Exception $ex) {
            $this->setCode(418);
            $this->setError(true);
            $this->setMessage("Error: {$ex->getMessage()} in class: " . __CLASS__ . ", method: " . __FUNCTION__ . ", file: " . __FILE__ . ", line: " . __LINE__ .
                " Object: " . $this->getModelName());
        }
        return $this->getResponse();
    }

    /**
     *  ______               _   _                 __  __      _   _               _     
     * |  ____|             | | | |               |  \/  |    | | | |             | |    
     * | |____   _____ _ __ | |_| |     ___   __ _| \  / | ___| |_| |__   ___   __| |___ 
     * |  __\ \ / / _ \ '_ \| __| |    / _ \ / _` | |\/| |/ _ \ __| '_ \ / _ \ / _` / __|
     * | |___\ V /  __/ | | | |_| |___| (_) | (_| | |  | |  __/ |_| | | | (_) | (_| \__ \
     * |______\_/ \___|_| |_|\__|______\___/ \__, |_|  |_|\___|\__|_| |_|\___/ \__,_|___/
     *                                        __/ |                                      
     *                                       |___/                                       
     */

    /** USER to set in eventLog */
    public $user = null;
    public function setThisUser(User $user)
    {
        $this->user = $user;
        return $this;
    }
    public function getThisUser()
    {
        return $this->user;
    }

    /** Valors in json */
    protected $jsonDataOld = null;
    protected $jsonDataNew = null;

    /** Method to set valors in eventLog */
    public function setEventLog(String $action = null, String $description = null, Bool $initResponse = false)
    {
        try {
            if ( $initResponse ) {
                $code = 400; $error = true; $message = 'There is an error to ' . __FUNCTION__ . ' method'; $data = []; $object = [];
                $this->initializeResponse( $code, $error, $message, $data, $object );
            }
            $this->setDebug( 'Init method: ' .  __FUNCTION__ );

            // USER field
            $this->user = ($this->user == null) ? (($this->existMethodInObject('getUser')) ? $this->getModel()->getUser() : $this->getThisUser()) : $this->user;

            // $this->user = ($this->user == null) ? $this->getUser() : $this->user;

            // if no user, get userAdmin
            if ( $this->user == null ) {
                $this->user = $this->entityManager->getRepository('App\Entity\User')->findOneBy( ['name' => 'Admin'] );
            }

            if ( $this->user != null ) {

                // description
                if ($description == null) {
                    $description = 'Automatic register eventLog for object ' . $this->getModelName() . (($action != null) ? ' in action ' . $action : '');
                }

                // setArrayToEventLog object
                $jsonDataOld = $this->jsonDataOld;
                $jsonDataNew = $this->jsonDataNew;

                // jsonData to array
                $jsonDataOld = $this->jsonToArray($this->jsonDataOld);
                $jsonDataNew = $this->jsonToArray($this->jsonDataNew);

                $dateTimeNow = new DateTime('now');
                $arrProperties = [
                    'user' => $this->user,
                    'objectId' => ($this->existMethodInObject('getId')) ? $this->getModel()->getId() : null,
                    'description' => $description,
                    'jsonDataOld' => $jsonDataOld,
                    'jsonDataNew' => $jsonDataNew,
                    'objectPropertiesChanged' => $this->getObjectPropertiesChanged($jsonDataOld, $jsonDataNew),
                    'status' => ($this->getError()) ? 'error' : 'correct', // * status: define the status of the action (error, correct)
                    'subStatus' => $this->getCode(), // * subStatus: define the level of the response action (code, 200, 400, 401, etc...)
                    'type' => $this->getModelName(), // * type: define the entityName. eventLog was default
                    'subType' => ($action != null) ? $action : '', // * subType: define the action in the object
                    'createdAt' => $dateTimeNow,
                    // 'updatedAt' => new DateTime('now'),
                    'timeZone' => ''
                ];
                $eventLogCRUD = new EventLogCRUD($this->entityManager, $this->logger);
                $eventLogCRUD->initCRUD();
                $this->setResponse($eventLogCRUD->create(null, $arrProperties, null));
                [$code, $error, $message, $data, $object] = $this->getResponse('unstructure');
            } else { [$code, $error, $message, $data, $object] = [400, true, 'Not found user to create eventLog registry', [], []];
            } // error 1

            // Set Response
            $this->finalResponse($code, $error, $message, $data, $object);
            $this->setDebug( 'Final method: ' .  __FUNCTION__ );

        } catch (Exception $ex) {
            $this->setCode(418);
            $this->setError(true);
            $this->setMessage("Error: {$ex->getMessage()} in class: " . __CLASS__ . ", method: " . __FUNCTION__ . ", file: " . __FILE__ . ", line: " . __LINE__ .
                " Object: " . $this->getModelName());
        }
        return $this->getResponse();
    }

    /** get Mothod of object */
    public function getObjectPropertiesChanged( $objectOld = null, $objectNew = null ): array
    {
        try {
            $response = [];
            if ($objectOld != null && is_array($objectOld)) { // only with two arrays
            // if ($objectNew != null && is_array($objectNew)) { // always
                $objectOldArray = ($objectOld != null && is_array($objectOld)) ? true : false;
                foreach ($objectNew as $keyNew => $valueNew) {
                    $propertieChanged = null;
                    if ($objectOldArray) {
                        foreach ($objectOld as $keyOld => $valueOld) {
                            $propertieChanged = ($keyOld == $keyNew && $valueOld != $valueNew) ? $keyNew : $propertieChanged;
                        }
                    } 
                    else { // all properties of the object
                        $propertieChanged = $keyNew;
                    }
                    // response
                    if ($propertieChanged != null) {
                        $response[] = $propertieChanged;
                    }
                }
            }
            $response = $this->jsonToArray( $response );

            // // old -> mixed
            // if ($objectNew != null && is_array($objectNew)) {
            //     $objectOldArray = ($objectOld != null && is_array($objectOld)) ? true : false;
            //     foreach ($objectNew as $keyNew => $valueNew) {
            //         $propertieChanged = null;
            //         if ($objectOldArray) {
            //             foreach ($objectOld as $keyOld => $valueOld) {
            //                 $propertieChanged = ($keyOld == $keyNew && $valueOld != $valueNew) ? $keyNew : $propertieChanged;
            //             }
            //         } 
            //         else { // all properties of the object
            //             $propertieChanged = $keyNew;
            //         }
            //         // response
            //         if ($propertieChanged != null) {
            //             $response[] = $propertieChanged;
            //         }
            //     }
            // }

        } catch (Exception $ex) {
            $this->setCode(418);
            $this->setError(true);
            $this->setMessage("Error: {$ex->getMessage()} in class: " . __CLASS__ . ", method: " . __FUNCTION__ . ", file: " . __FILE__ . ", line: " . __LINE__ .
                " Object: " . $this->getModelName());
        }
        return $response;
    }

    /** jsonToArray */
    protected function jsonToArray( $jsonObject = null ): ?Array 
    {
        try {
            // jsonData to array
            if ( getType($jsonObject) != 'array' ) {                    
                if ( getType($jsonObject) == 'string' ) {
                    $jsonObject = json_decode($jsonObject); // json to object
                    $jsonObject = json_decode(json_encode($jsonObject), true); // Converting an array/stdClass -> array
                } 
                else if ( getType($jsonObject) == 'stdClass' ) {
                    $jsonObject = json_decode(json_encode($jsonObject), true); // Converting an array/stdClass -> array
                } else {
                    $jsonObject = null;
                }
            }            
        } catch (Exception $ex) {
            $this->setCode(418);
            $this->setError(true);
            $this->setMessage("Error: {$ex->getMessage()} in class: " . __CLASS__ . ", method: " . __FUNCTION__ . ", file: " . __FILE__ . ", line: " . __LINE__ .
                " Object: " . $this->getModelName());
        }
        return $jsonObject;
    }

    /**
     *             _ _     _       _       __  __      _   _               _     
     *            | (_)   | |     | |     |  \/  |    | | | |             | |    
     * __   ____ _| |_  __| | __ _| |_ ___| \  / | ___| |_| |__   ___   __| |___ 
     * \ \ / / _` | | |/ _` |/ _` | __/ _ \ |\/| |/ _ \ __| '_ \ / _ \ / _` / __|
     *  \ V / (_| | | | (_| | (_| | ||  __/ |  | |  __/ |_| | | | (_) | (_| \__ \
     *   \_/ \__,_|_|_|\__,_|\__,_|\__\___|_|  |_|\___|\__|_| |_|\___/ \__,_|___/                                                           
     */

    private $arrayFinalProperties;
    /** Compose object from param receibed - We can get request, arrProperties or object */
    protected function setValuesModel(Request $request = null, ?array $arrProperties = null, Object $object_ = null): ?array
    {
        try {
            $code = 400; $error = true; $message = 'There is an error to create method'; $data = []; $object = [];
            $this->initializeResponse($code, $error, $message, $data, $object);
            $this->setDebug( 'Init method: ' .  __FUNCTION__ );

            // Search in params receibed
            $arrayFinalProperties = array();
            if ($request != null || ($arrProperties != null && is_array($arrProperties) && count($arrProperties) >= 1) || $object_ != null) {
                // Extract properties of param received - request, arrProperties or Object
                foreach ($this->getModelProperties($this->model) as $value) {
                    if ($value != 'id') {
                        $method = 'get' . ucfirst($value);

                        // object
                        if ($object_ != null && $this->existMethodInObject($method)) {
                            $arrayFinalProperties[$value] = (array_key_exists($value, $arrayFinalProperties)) ? $arrayFinalProperties[$value] : $object_->$method();
                            $error = false;
                        }

                        // request
                        if ($request != null && ($request->request->has('_' . $value))) {
                            $arrayFinalProperties[$value] = $request->request->get('_' . $value);
                            $error = false;
                        }
                        // arrProperties
                        else if (is_array($arrProperties) && array_key_exists($value, $arrProperties)) {
                            $arrayFinalProperties[$value] = $arrProperties[$value];
                            $error = false;
                        }

                        if (array_key_exists($value, $arrayFinalProperties) && $arrayFinalProperties[$value] == '{null}') {
                            $arrayFinalProperties[$value] = null;
                        }

                        // old code to do action
                        // $property = ( $request != null && ( $request->request->has('_' . $value) ) ) ? $request->request->get('_' . $value) // REQUEST
                        //     : ( ( is_array($arrProperties) && array_key_exists($value, $arrProperties) ) ? $arrProperties[$value] // ARRAY
                        //     : ( ( $object_ != null && $this->existMethodInObject($method) ) ? $object_->$method() // OBJECT
                        //     : 'NOT-GET-PARAM-IN-THIS-METHOD') );
                        // if ( $property != 'NOT-GET-PARAM-IN-THIS-METHOD' ) { 
                        //     $arrayFinalProperties[$value] = $property; 
                        //     $error = false;
                        // }
                    }
                }
                $this->setDebug( json_encode(['arrayFinalProperties' => $arrayFinalProperties]) );

                if (!is_array($arrayFinalProperties) || count($arrayFinalProperties) == 0) { // Error General 2
                    $error = true;
                    $message = "No get params to process in method " . __FUNCTION__ .  " in class: " . __CLASS__ . " (General error 2) of " . $this->getModelName();
                } else {
                    $this->arrayFinalProperties = $arrayFinalProperties;
                    if (!$error) { // Error 1

                        if ( $object_ != null ) {
                            $this->setModel( $object_ );
                        }

                        $this->setResponse($this->processProperties($arrayFinalProperties)); // Process properties
                        if (!$this->getError()) { // Error 2

                            $arrayFinalProperties = $this->getObject();
                            foreach ($this->getModelProperties($this->getModel()) as $value) { // Set Model
                                if ($value != 'id' && array_key_exists($value, $arrayFinalProperties)) { // $arrayFinalProperties[$key] ) { $method = 'set' . ucfirst($key);
                                    $method = 'set' . ucfirst($value);
                                    if ($this->existMethodInObject($method)) {
                                        $this->model->$method($arrayFinalProperties[$value]);
                                    }
                                }
                            } // Prepare response -->
                            if (!$this->getError()) { // Error 3
                                [$code, $error, $message, $data, $object] = [200, false, 'Set values model correct ', $arrayFinalProperties, $this->model];
                            } // Error 3
                        } else { [$code, $error, $message, $data, $object] = $this->getResponse('unstructure'); } // Error 2
                    } // Error 1
                }
            } else { // Error General 1
                $message = "No get data to process in method " . __FUNCTION__ .  " in class: " . __CLASS__ . " (General error 2) in " . $this->getModelName();
            } // Error General 1

            // Set Response
            $this->finalResponse($code, $error, $message, $data, $object);
            $this->setDebug( json_encode([__FUNCTION__ => $this->getResponse()]) );
            $this->setDebug( 'Final method: ' .  __FUNCTION__ );

        } catch (Exception $ex) {
            $this->setCode(418);
            $this->setError(true);
            $this->setMessage("Error: {$ex->getMessage()} in class: " . __CLASS__ . ", method: " . __FUNCTION__ . ", file: " . __FILE__ . ", line: " . __LINE__ .
                " Object: " . $this->getModelName());
        }
        return $this->getResponse();
    }

    /** Params uniques and repeat in object */
    protected $methodsToValidateCreate = [];
    public function setMethodsToValidateCreate(array $methodsToValidateCreate)
    {
        $this->methodsToValidateCreate = $methodsToValidateCreate;
        return $this;
    }
    public function addMethodsToValidateCreate(String $methodsToValidateCreate)
    {
        if (!in_array($methodsToValidateCreate, $this->methodsToValidateCreate)) {
            $this->methodsToValidateCreate[] = $methodsToValidateCreate;
        }
        return $this;
    }

    /** Validate Data to create - WORK in all objects 
     * this work because we have to set poperties:
     * required
     * unique (to findObjectByUniqueParams)
     */
    protected function validateDataToCreate(Request $request = null, ?array $arrProperties = null, Object $object_ = null): ?array
    {
        try {
            $code = 400; $error = true; $message = 'There is an error to ' . __FUNCTION__ . ' method'; $data = []; $object = [];
            $this->initializeResponse($code, $error, $message, $data, $object);
            $this->setDebug( 'Init method: ' .  __FUNCTION__ );

            // Required Params
            $error_ = false; // error to control
            if (count($this->requiredParams) >= 1) {
                $this->setDebug( json_encode(['requiredParams' => $this->requiredParams]) );

                $flag = false;
                foreach ($this->requiredParams as $value) {
                    if ($request != null && !$request->request->has('_' . $value)) {
                        $flag = true;
                    }
                    if (is_array($arrProperties) && count($arrProperties) >= 1 && !array_key_exists($value, $arrProperties)) {
                        $flag = true;
                    }
                    $method = 'get' . ucfirst($value);
                    if ($object_ != null && $this->existMethodInObject($method) && ($object_->$method() == null || $object_->$method() == '')) {
                        $flag = true;
                    }

                    // TODO: validate if valor get in the same element ( request, arrayProperties or object_ )
                    if ($flag) {
                        $flag = false;
                        $error_ = true;
                        $message = 'No get property ' . $value . ' to create Object ' . $this->getModelName();
                    }
                }
            }

            // Unique params
            if (!$error_ && count($this->uniqueParams) >= 1) { // Error 1
                $this->setDebug( json_encode(['uniqueParams' => $this->uniqueParams]) );

                $this->setResponse($this->findObjectByUniqueParams($request, $arrProperties, $object_, 'create'));
                [$code, $error, $message, $data, $object] = $this->getResponse('unstructure');
                $error_ = $error;
            } // Error 1

            // Methods Validate to create ???
            if (!$error_ && count($this->methodsToValidateCreate) >= 1) { // Error 2
                $this->setDebug(json_encode(['methodsToValidateCreate' => $this->methodsToValidateCreate]));

                foreach ($this->methodsToValidateCreate as $value) {
                    if ($this->existMethodInObject($value, $this)) {
                        $this->setResponse($this->$value($this->arrayFinalProperties));
                        [$code, $error, $message, $data, $object] = $this->getResponse('unstructure');
                        $error_ = ($error) ? true : $error_;
                    } else {
                        $this->setDebug( json_encode([$value => 'Not exist']), 'warning' );
                    }
                }
            } // Error 2

            // Methods Advise
            if (!$error_ && count($this->adviseParams) >= 1) { // Error 3
                $message = 'Method ' . __FUNCTION__ . ' executed correct';
                foreach ($this->adviseParams as $value) {
                    $method = 'get' . ucfirst($value);
                    if ($this->existMethodInObject($method) && !$this->model->$method()) {
                        $message = $message . " - Advise, No property $value found in " . $this->getModelName() . " \n";
                        $data['advise'][] = $message;
                        $this->setDebug( json_encode(['adviseParams' => $value]), 'warning' );
                    }
                }
            } // Error 3

            if (!$error_) {
                $code = 200;
                $error = false;
                $message = 'Method ' . __FUNCTION__ . ' executed correct';
            } else {
                $code = 400;
                $error = true;
            }

            // Set Response
            $this->finalResponse($code, $error, $message, $data, $object);
            $this->setDebug( json_encode([__FUNCTION__ => $this->getResponse()]) );
            $this->setDebug( 'Final method: ' .  __FUNCTION__ );

        } catch (Exception $ex) {
            $this->setCode(418);
            $this->setError(true);
            $this->setMessage("Error: {$ex->getMessage()} in class: " . __CLASS__ . ", method: " . __FUNCTION__ . ", file: " . __FILE__ . ", line: " . __LINE__ .
                " Object: " . $this->getModelName());
        }
        return $this->getResponse();
    }

    /** Find object by unique params with groupUniqueParams
     * This is an special method, -> Se tendrá en cuenta la logica de update or delete
     * update if found $this->getError() == false
     * create if found $this->getError() == true
     */
    public function findObjectByUniqueParams(Request $request = null, array $arrProperties = null, Object $object_ = null, String $logic = 'update'): ?array
    {
        try {
            // [$code, $error, $message, $data, $object] = $this->getResponse('unstructure');
            // $message = 'There is no actions for ' . __FUNCTION__;
            [$code, $error, $message, $data, $object] = [200, false, 'There is no actions for ' . __FUNCTION__, [], []];
            $this->initializeResponse($code, $error, $message, $data, $object);
            $this->setDebug( 'Init method: ' .  __FUNCTION__ . ' for ' . $logic );

            $repositoryName = "App\Entity\\" . $this->getModelName();

            // unique params
            if ( is_array($this->uniqueParams) && count($this->uniqueParams) >= 1 ) {
                $this->setDebug( ' uniqueParams 0 - ' . __FUNCTION__ );
            
                $objectFoundUniqueParams = null;
                $objectDuplicated = false;
                $objectsFound = [];
                $objectFound_ = null;
                foreach ( $this->uniqueParams as $valueUniqueParam ) {
                    $this->setDebug( ' valueUniqueParam: - ' . $valueUniqueParam );

                    // search object with params and validate if object
                    if ( !$error ) {
                        // by object
                        $method = 'get' . ucfirst($valueUniqueParam);
                        if ( $object_ != null && $this->existMethodInObject( $method ) ) {
                            $paramsType = 'object';
                            // $objectFound = $this->entityManager->getRepository($repositoryName)->FindOneBy([$valueUniqueParam => $object_->$method]);
                            $objectFound_ = $this->entityManager->getRepository($repositoryName)->FindBy([$valueUniqueParam => $object_->$method()]);
                            if ( $objectFound_ != null && count( $objectFound_ ) == 0 && $objectFound_[0] != $object_ ) {
                                $objectDuplicated = true;
                                $this->setDebug( ' object duplicate by object - ' . __FUNCTION__ );
                                $this->setDebug( json_encode(['objectFound' => $this->serializer->serialize($objectFound_[0], 'json')]) );
                            }
                        }
                        // by request
                        if ($request != null && $request->request->has('_' . $valueUniqueParam)) {
                            $paramsType = 'request';
                            $this->setDebug( ' request - ' . __FUNCTION__ . ' param: ' . $valueUniqueParam );
                            $requestValue = $request->request->get('_' . $valueUniqueParam);
                            // $objectFound = $this->entityManager->getRepository($repositoryName)->FindOneBy([$valueUniqueParam => $requestValue]);
                            $objectFound_ = $this->entityManager->getRepository($repositoryName)->FindBy([$valueUniqueParam => $requestValue]);
                        }
                        // by arrProperties
                        else if ($arrProperties != null && array_key_exists($valueUniqueParam, $arrProperties)) {
                            $paramsType = 'array';
                            $this->setDebug( ' array - ' . __FUNCTION__ . ' param: ' . $valueUniqueParam );
                            // $objectFound = $this->entityManager->getRepository($repositoryName)->FindOneBy([$valueUniqueParam => $arrProperties[$valueUniqueParam]]);
                            $objectFound_ = $this->entityManager->getRepository($repositoryName)->FindBy([$valueUniqueParam => $arrProperties[$valueUniqueParam]]);
                        }

                        // error duplicated found
                        if ( $objectFound_ != null && ( count( $objectFound_ ) > 1 || $objectDuplicated ) ) {
                            $this->setDebug( ' uniqueParams 5 - ' . __FUNCTION__ );
                            $code = 400;
                            $error = true;
                            $message = 'Object ' . $this->getModelName() . ' duplicated in BBDD with '; 
                            $message .= ' value "' . $objectFound_[0]->$method . '"'; 
                            $message .= ' in propertie "' . $valueUniqueParam . '"';  
                            $message .= ' . Found with paramType "' . $paramsType . '"';
                        } 
                        // add objectFound to array if no in array
                        else if ( $objectFound_ != null && !in_array( $objectFound_[0], $objectsFound ) ) {
                            $this->setDebug( ' uniqueParams 6 - ' . __FUNCTION__ );
                            $objectFoundUniqueParams = $objectFound_[0];
                            $objectsFound[] = $objectFoundUniqueParams;
                            
                        }
                    }
                }

                // validate only 0 or 1 objectFound may be in array $objectsFound
                if ( count( $objectsFound ) > 1 ) {
                    $code = 400;
                    $error = true;
                    $message = 'Object ' . $this->getModelName() . ' duplicated in BBDD';
                    $this->setDebug( json_encode(['objectFound' => $this->serializer->serialize($objectsFound, 'json')]) );
                }            
            }
            $this->setDebug( ' 7 - ' . __FUNCTION__ );

            // group unique params
            $groupUniqueParms = false;
            if ( is_array($this->groupUniqueParams) && count($this->groupUniqueParams) > 0 ) {
                $repositoryName = "App\Entity\\" . $this->getModelName();
                $objectFoundGroupUniqueParams = null;
                $objectDuplicated = false;
                $arrayForSearch = [];
                $arrayForSearch_object = [];
                $objectFound_ = null;
                foreach ($this->groupUniqueParams as $valueGroupUniqueParams) {

                    // by object
                    $method = 'get' . ucfirst($valueGroupUniqueParams);
                    if ( $object_ != null && $this->existMethodInObject( $method ) ) {
                        $paramsType = 'object';
                        $arrayForSearch_object[$valueGroupUniqueParams] = $object_->$method();
                    }
                    // by request
                    if ($request != null && $request->request->has('_' . $valueGroupUniqueParams)) {
                        $paramsType = 'request';
                        $arrayForSearch[$valueGroupUniqueParams] = $request->request->get('_' . $valueGroupUniqueParams);
                    } 
                    // by array
                    else if ($arrProperties != null && array_key_exists($valueUniqueParam, $arrProperties)) {
                        $paramsType = 'array';
                        $arrayForSearch[$valueGroupUniqueParams] = $arrProperties[$valueGroupUniqueParams];
                    }
                }

                // exec search object in BBDD
                if ( count($arrayForSearch_object) == count( $this->groupUniqueParams ) ) {
                    $groupUniqueParms = true;
                    $objectFound_ = $this->entityManager->getRepository($repositoryName)->FindBy( $arrayForSearch_object );
                    if ( $objectFound_ != null && count( $objectFound_ ) == 0 && $objectFound_[0] != $object_ ) {
                        $objectDuplicated = true;
                    }
                }
                if ( count($arrayForSearch) == count( $this->groupUniqueParams ) ) {
                    $groupUniqueParms = true;
                    $objectFound_ = $this->entityManager->getRepository($repositoryName)->FindBy( $arrayForSearch );
                }

                // error duplicated found
                if ( $objectFound_ != null && ( count( $objectFound_ ) > 1 || $objectDuplicated) ) {
                    $code = 400;
                    $error = true;
                    $message = 'Object ' . $this->getModelName() . ' duplicated in BBDD with ';
                    $n=0; 
                    $arrayToIterate = ( $objectDuplicated ) ? $arrayForSearch_object : $arrayForSearch;
                    foreach ($arrayToIterate as $keyArrayToIterate => $valueArrayToIterate) {
                        if ( $n > 0 ) {
                            $message .= ' and'; 
                        }
                        $message .= ' value "' . $keyArrayToIterate . '"'; 
                        $message .= ' in propertie "' . $valueArrayToIterate . '"';
                        $n++;
                    }
                    $message .= ' . Found with paramType "' . $paramsType . '"';
                } 
                // add objectFound to array if no in array
                else { $objectFoundGroupUniqueParams = $objectFound_; }
            }

            // validate for create or update
            if ( !$error ) {
                $this->setDebug( ' Response - 0 - ' . __FUNCTION__ );

                // create
                if ( $logic == 'create' ) {
                    if ( $objectFoundUniqueParams != null ) {
                        [$code, $error, $message, $data, $object] = [400, true, 'Object found in BBDD with uniqueParams - ko for create', $data, $objectFoundUniqueParams];
                    } else {
                        [$code, $error, $message, $data, $object] = [200, false, 'Object not found in BBDD with uniqueParams - ok for create', $data, $object];
                    }
                    // code 200 and groupUniqueParams
                    if ( !$error && $groupUniqueParms ) {
                        if ( $objectFoundGroupUniqueParams != null ) {
                            [$code, $error, $message, $data, $object] = [400, true, 'Object found in BBDD with groupsUniqueParams - ko for create', $data, $object];
                        } else {
                            [$code, $error, $message, $data, $object] = [200, false, 'Object not found in BBDD with groupsUniqueParams - ok for create', $data, $object];
                        }
                    }
                }
                // update
                else {
                    if ( $objectFoundUniqueParams != null ) {
                        [$code, $error, $message, $data, $object] = [200, false, 'Object found in BBDD with uniqueParams - ok for update', $data, $objectFoundUniqueParams];
                        $this->setModel( $objectFoundUniqueParams );
                        $this->jsonDataOld = $this->serializer->normalize($this->model);
                    } else {
                        [$code, $error, $message, $data, $object] = [400, true, 'Object not found in BBDD with uniqueParams - ko for update', $data, $object];
                    }
                }
            }

            // Set Response
            $this->finalResponse($code, $error, $message, $data, $object);
            $this->setDebug( json_encode([__FUNCTION__ => $this->getResponse()]) );
            $this->setDebug( 'final method: ' .  __FUNCTION__ . ' for ' . $logic );











            // $code = 400; $error = true; $message = 'There is an error to ' . __FUNCTION__ . ' method'; $data = []; $object = [];
            // $error = ($logic === 'update') ? true : false; // if is an update, the error initialize true else false
            // $message = ($logic == 'update') ? 'not ' : ''; // if is an update, set not

            // $message = $this->getModelName() . ' object ' . $message . 'exist for ' . $logic;
            // $this->initializeResponse($code, $error, $message, $data, $object);
            // $this->setDebug( 'Init method: ' .  __FUNCTION__ . ' for ' . $logic );

            // // Search properties
            // $repositoryName = "App\Entity\\" . $this->getModelName();
            // $objectFound = null;
            // $withUniqueParams = false;
            // if (is_array($this->uniqueParams) && count($this->uniqueParams) >= 1) {
            //     $withUniqueParams = true;
            //     foreach ($this->uniqueParams as $value) {

            //         // search object with params and validate if object
            //         if ($objectFound == null) {
            //             $method = 'get' . ucfirst($value);

            //             // by request
            //             if ($request != null && $request->request->get('_' . $value)) {
            //                 $objectFound = $this->entityManager->getRepository($repositoryName)->FindOneBy([$value => $request->request->get('_' . $value)]);
            //                 $this->setDebug( '-1 - ' . __FUNCTION__ );
            //             }
            //             // by arrProperties
            //             else if ($arrProperties != null && is_array($arrProperties) && count($arrProperties) >= 1 && array_key_exists($value, $arrProperties)) {
            //                 $objectFound = $this->entityManager->getRepository($repositoryName)->FindOneBy([$value => $arrProperties[$value]]);
            //                 $this->setDebug( '-2 - ' . __FUNCTION__ );
            //                 $this->setDebug( $this->serializer->serialize( $objectFound, 'json' ) );
            //             }

            //             // by object
            //             if ($object_ != null && $this->existMethodInObject($method)) {
            //                 $this->setDebug( '0 - ' . __FUNCTION__ );

            //                 if ( $logic == 'update' && $object_->getId() == null ) {
            //                     $this->setDebug( '1 - ' . __FUNCTION__ );
            //                     $objectFound = null;
            //                     $error = true;
            //                     $messageError = 'Not exist Object in BBDD for update ';
            //                 } else {
            //                     $this->setDebug( '2 - ' . __FUNCTION__ );
            //                     // Validate for duplicate registry
            //                     $objectDuplicate = (isset($objectDuplicate)) ? $objectDuplicate : false;
            //                     if ($objectFound != null) {
            //                         $this->setDebug( '3 - ' . __FUNCTION__ );
            //                         if ( $this->existMethodInObject('getId') && $object_->getId() != null ) {
            //                             $this->setDebug( '4 - ' . __FUNCTION__ );
            //                             if ( $object_->getId() != $objectFound->getId() ) {
            //                                 $this->setDebug( '5 - ' . __FUNCTION__ );
            //                                 $objectDuplicate = true;
            //                                 $error = true;
            //                                 $messageError = 'Exist other object with the same value in propertie: ' . $value;
            //                             }
            //                         } 
            //                     }
            //                     if (!$objectDuplicate) {
            //                         $objectFound = $object_;
            //                     }
            //                 }
            //             }
            //         }
            //         // final result in this foreach
            //         if ($objectFound != null) {
            //             $error = ($logic == 'update') ? false : true;
            //             if (isset($objectDuplicate) && $objectDuplicate) {
            //                 $error = true;
            //             }
            //         }
            //     }
            // } // else 
            // $this->setDebug( '10 - ' . $error . ' - ' . $message );


            // // groupUniqueParams
            // if ($logic != 'update' && is_array($this->groupUniqueParams) && count($this->groupUniqueParams) >= 1) {
            //     $withUniqueParams = true;
            //     $finalArray = [];
            //     foreach ($this->groupUniqueParams as $value) {
            //         $method = 'get' . ucfirst($value);
            //         $finalArray[$value] = ($request != null && $request->request->get('_' . $value)) ? $request->request->get('_' . $value) : // REQUEST                                                        
            //             (($arrProperties != null && is_array($arrProperties) && count($arrProperties) >= 1 && array_key_exists($value, $arrProperties)) ? // ArrayProperties
            //                 $arrProperties[$value] : (($object != null && $this->existMethodInObject($method)) ? $object_->$method() // Object                            
            //                     : false)); // Not found
            //     }
            //     $objectFound = (is_array($finalArray) && count($finalArray) >= 1) ? $this->entityManager->getRepository($repositoryName)->FindOneBy($finalArray) : $objectFound;
            //     if ($objectFound !== null) {
            //         // $this->setError( ($logic == 'update') ? false : true);
            //         $error = ($logic == 'update') ? false : true;
            //     }
            // } // With no unique params to validate, response with no error
            // // else

            // if (!$withUniqueParams) {
            //     // $this->initializeResponse(200, false, $this->objectName . ' object without unique params to validate'); 
            //     $code = 200;
            //     $error = false;
            //     $message = $this->getModelName() . ' object without unique params to validate';
            // }
            // // with unique params to validate
            // if ($objectFound != null && $this->existMethodInObject('getId', $objectFound)) { // $objectFound->getId() ) { // Found
            //     // To eventLog
            //     $this->jsonDataOld = $this->normalizeObjectFull($objectFound, 1);

            //     $code = 200;
            //     $message = $this->getModelName() . ' object found in BBDD with id: ' . $objectFound->getId();
            //     // For update set model
            //     if ($logic == 'update') {
            //         $this->setModel($objectFound);
            //         if ($error) {
            //             $code = 400;
            //             $message = (isset($messageError)) ? $messageError : $message;
            //         }
            //     }
            //     // For create set in object
            //     else { $object = $objectFound; }
            //     $data['objectNormalized'] = $this->normalizeObjectFull($objectFound, 1, $this->getModelName());
            // } // Found  

            // // Set Response
            // $this->finalResponse($code, $error, $message, $data, $object);
            // $this->setDebug( json_encode([__FUNCTION__ => $this->getResponse()]) );
            // $this->setDebug( 'final method: ' .  __FUNCTION__ );

        } catch (Exception $ex) {
            $this->setCode(418);
            $this->setError(true);
            $this->setMessage("Error: {$ex->getMessage()} in class: " . __CLASS__ . ", method: " . __FUNCTION__ . ", file: " . __FILE__ . ", line: " . __LINE__ .
                " Object: " . $this->getModelName());
        }
        return $this->getResponse();
    }

    /** Search method in $object or $this->getModel() */
    public function existMethodInObject(string $methodName, Object $object = null): ?bool
    {
        try {
            $methodFound = false;
            $object = ($object != null) ? $object : $this->getModel();
            foreach ($this->getModelMethods($object) as $value) {
                $methodFound = ($methodName === $value) ? true : $methodFound;
            }
        } catch (Exception $ex) {
            $this->setCode(418);
            $this->setError(true);
            $this->setMessage("Error: {$ex->getMessage()} in class: " . __CLASS__ . ", method: " . __FUNCTION__ . ", file: " . __FILE__ . ", line: " . __LINE__ .
                " Object: " . $this->getModelName());
        }
        return $methodFound;
    }


    /** Params uniques and repeat in object */
    protected $methodsProcessProperties = [];
    public function setMethodsProcessProperties(array $methodsProcessProperties)
    {
        $this->methodsProcessProperties = $methodsProcessProperties;
        return $this;
    }
    public function addMethodsProcessProperties(String $methodsProcessPropertie)
    {
        if (!in_array($methodsProcessPropertie, $this->methodsProcessProperties)) {
            $this->methodsProcessProperties[] = $methodsProcessPropertie;
        }
        return $this;
    }

    /** Default method with no actions - Used for object that no need validate properties */
    protected function processProperties(?array $arrProperties = null)
    {
        try {
            $this->initializeResponse(403, false, $this->getMessage());
            if (count($this->methodsProcessProperties) >= 1) { // Method extra - if exist
                foreach ($this->methodsProcessProperties as $value) {
                    if (!$this->getError()) {
                        $this->setResponse($this->$value($arrProperties));
                    }
                    if (!$this->getError()) {
                        $arrProperties = $this->getObject();
                    }
                }
            }
            if (!$this->getError()) {
                $this->setCode(200);
                $this->setObject($arrProperties);
            }
        } catch (Exception $ex) {
            $this->setCode(418);
            $this->setError(true);
            $this->setMessage("Error: {$ex->getMessage()} in class: " . __CLASS__ . ", method: " . __FUNCTION__ . ", file: " . __FILE__ . ", line: " . __LINE__ .
                " Object: " . $this->getModelName());
        }
        return $this->getResponse();
    }

    /**
     *                                   _ _          ____  _     _           _   
     *                                  | (_)        / __ \| |   (_)         | |  
     *  _ __   ___  _ __ _ __ ___   __ _| |_ _______| |  | | |__  _  ___  ___| |_ 
     * | '_ \ / _ \| '__| '_ ` _ \ / _` | | |_  / _ \ |  | | '_ \| |/ _ \/ __| __|
     * | | | | (_) | |  | | | | | | (_| | | |/ /  __/ |__| | |_) | |  __/ (__| |_ 
     * |_| |_|\___/|_|  |_| |_| |_|\__,_|_|_/___\___|\____/|_.__/| |\___|\___|\__|
     *                                                          _/ |              
     *                                                         |__/              
     */

    public $excludeNorm = [];
    public $noExcludeNorm = [];
    public $defaultLevel = 2;
    /** 
     * Method to normalize the object
     * 
     * @param Object    $objectNormalize    The object to normalize
     * @param Int       $level              The level to down
     * @param String    $entityType         type of entity to normalize
     * @param String    $preEntity          type of entity last normalized
     * 
     * @return Array    the response value
     * 
     * @author  antonio.rodrigo
     */
    public function normalizeObjectFull(Object $objectNormalize, Int $level = 1, String $entityType = null, String $preEntity = null): ?array
    {
        try {
            // $this->initializeResponse(403, true);
            $maxLevel = 2;
            $level = ($level === null) ? $maxLevel : ((gettype($level) === 'integer') ? $level : $maxLevel);
            $excludeValors = ['password', 'plainPassword'];
            $dateValors = ['createdAt', 'createdLocalAt', 'updatedAt', 'startDate', 'endDate', 'dateAt', 'expenseDate', 'denyDate', 'approveDate', 'adminDate', 'paymentDate'];
            $collectionToNormalize = ['permissions', 'ticketsAssign'];
            $this->excludeNorm[] = 'offset';

            $arrResult = array();
            $thisEntity = explode("\\", get_class($objectNormalize));
            if (is_array($thisEntity) && count($thisEntity) >= 1) {
                $entityType_ = lcfirst(trim(end($thisEntity)));
            } else {
                $entityType_ = $entityType;
            }

            if ($level > 0) {
                $propertiesOfObject = $this->getArrProperties($objectNormalize);
                // $arrResult[]['properties'] = $this->getArrProperties($objectNormalize);
                // $arrResult[]['entity'] = $entityType_;
                // $arrResult[]['entities'] = $this->excludeNorm;
                foreach ($propertiesOfObject as $key_ => $key) {
                    $method = 'get' . ucfirst($key); // <-- METHOD TO GET ****************

                    $getThis = true;
                    $getThis = (count($this->excludeNorm) < 1) ? true : $getThis;
                    // individual
                    $getThis = (count($this->excludeNorm) > 0 && in_array($key, $this->excludeNorm)) ? false : $getThis;
                    // Pre Entity
                    if (count($this->excludeNorm) > 0 && in_array('preEntity', $this->excludeNorm) || 1 == 1) {
                        $getThis = (strtolower($key) == strtolower($preEntity)) ? false : $getThis;
                    }
                    // key in entity ej: excludeNorm = ['groups', 'ticket' => 'comments'] 
                    if (count($this->excludeNorm) > 0 && array_key_exists($entityType_, $this->excludeNorm) && is_array($this->excludeNorm[$entityType_])) {
                        // force
                        if (array_key_exists('forceEntityParams', $this->excludeNorm[$entityType_])) {
                            $getThis = (!in_array($key, $this->excludeNorm[$entityType_]['forceEntityParams'])) ? false : $getThis;
                        }
                        // exclude
                        else {
                            $getThis = (in_array($key, $this->excludeNorm[$entityType_]) || $this->excludeNorm[$entityType_] == null) ? false : $getThis;
                        }
                    }

                    // NORMALIZE
                    if ($getThis) {
                        if ($this->existMethodInObject($method, $objectNormalize)) {
                            if (getType($objectNormalize->$method()) != 'object') { // Normal and excluded
                                $arrResult[$key] = (!in_array($key, $excludeValors)) ? $objectNormalize->$method() : '*****';
                            } else if (in_array($key, $dateValors)) { // date type
                                $arrResult[$key] = $objectNormalize->$method();
                            } else if (!$objectNormalize->$method() instanceof PersistentCollection) { // renormalized
                                $arrResult[$key] = $this->normalizeObjectFull($objectNormalize->$method(), $level - 1, $key, $entityType_);
                            } else { // Collections
                                $key_ = ucfirst(substr($key, 0, -1)); // extract 's'
                                foreach ($objectNormalize->$method() as $keyCollection => $valueCollection) {
                                    $arrResult[$key][$keyCollection] =
                                        $this->normalizeObjectFull($valueCollection, $level - 1, $key_, $entityType_);
                                }
                            }
                        }
                    }
                }
            } else {
                // default methods
                if ($this->existMethodInObject('getId', $objectNormalize)) {
                    $arrResult['id'] = $objectNormalize->getId();
                }
                if ($this->existMethodInObject('getName', $objectNormalize)) {
                    $arrResult['name'] = $objectNormalize->getName();
                }
            }
            unset($objectNormalize);
        } catch (Exception $ex) {
            // $this->setCode(500);
            // $this->setError(true);
            // $this->setMessage("Error: {$ex->getMessage()} in class: " . __CLASS__.
            // ", method: " . __FUNCTION__ . ", file: " . __FILE__ . ", line: " . __LINE__.
            // " Object: " . $this->objectName );
            $arrResult['Error'] = "Error: {$ex->getMessage()} in class: " . __CLASS__ .
                ", method: " . __FUNCTION__ . ", file: " . __FILE__ . ", line: " . __LINE__ .
                " Object: " . $this->getModelName();
        }
        return $arrResult;
    }

    /** TRANSACTION */
    /**
     * Begin transaction
     */
    public function beginTransaction()
    {
        $this->entityManager->beginTransaction();
    }

    /**
     * Commit transaction
     */
    public function commit()
    {
        $this->entityManager->getConnection()->commit();
    }

    /**
     * RollBack transaction
     */
    public function rollBack()
    {
        $this->entityManager->getConnection()->rollBack();
    }

    /**
     * DEPRECATED
     */
    public function findObjectByUniqueParams_(Request $request = null, ?array $arrProperties = null, Object $object_ = null, String $logic = 'update'): ?array
    {
        try {
            $code = 400; $error = true; $message = 'There is an error to ' . __FUNCTION__ . ' method'; $data = []; $object = [];
            $error = ($logic === 'update') ? true : false; // if is an update, the error initialize true else false
            $message = ($logic == 'update') ? 'not ' : ''; // if is an update, set not

            $message = $this->getModelName() . ' object ' . $message . 'exist for ' . $logic;
            $this->initializeResponse($code, $error, $message, $data, $object);
            $this->setDebug( 'Init method: ' .  __FUNCTION__ . ' for ' . $logic );

            // Search properties
            $repositoryName = "App\Entity\\" . $this->getModelName();
            $objectFound = null;
            $withUniqueParams = false;
            if (is_array($this->uniqueParams) && count($this->uniqueParams) >= 1) {
                $withUniqueParams = true;
                foreach ($this->uniqueParams as $value) {

                    // search object with params and validate if object
                    if ($objectFound == null) {
                        $method = 'get' . ucfirst($value);

                        // by request
                        if ($request != null && $request->request->get('_' . $value)) {
                            $objectFound = $this->entityManager->getRepository($repositoryName)->FindOneBy([$value => $request->request->get('_' . $value)]);
                            $this->setDebug( '-1 - ' . __FUNCTION__ );
                        }
                        // by arrProperties
                        else if ($arrProperties != null && is_array($arrProperties) && count($arrProperties) >= 1 && array_key_exists($value, $arrProperties)) {
                            $objectFound = $this->entityManager->getRepository($repositoryName)->FindOneBy([$value => $arrProperties[$value]]);
                            $this->setDebug( '-2 - ' . __FUNCTION__ );
                            $this->setDebug( $this->serializer->serialize( $objectFound, 'json' ) );
                        }

                        // by object
                        if ($object_ != null && $this->existMethodInObject($method)) {
                            $this->setDebug( '0 - ' . __FUNCTION__ );

                            if ( $logic == 'update' && $object_->getId() == null ) {
                                $this->setDebug( '1 - ' . __FUNCTION__ );
                                $objectFound = null;
                                $error = true;
                                $messageError = 'Not exist Object in BBDD for update ';
                            } else {
                                $this->setDebug( '2 - ' . __FUNCTION__ );
                                // Validate for duplicate registry
                                $objectDuplicate = (isset($objectDuplicate)) ? $objectDuplicate : false;
                                if ($objectFound != null) {
                                    $this->setDebug( '3 - ' . __FUNCTION__ );
                                    if ( $this->existMethodInObject('getId') && $object_->getId() != null ) {
                                        $this->setDebug( '4 - ' . __FUNCTION__ );
                                        if ( $object_->getId() != $objectFound->getId() ) {
                                            $this->setDebug( '5 - ' . __FUNCTION__ );
                                            $objectDuplicate = true;
                                            $error = true;
                                            $messageError = 'Exist other object with the same value in propertie: ' . $value;
                                        }
                                    } 
                                }
                                if (!$objectDuplicate) {
                                    $objectFound = $object_;
                                }
                            }
                        }
                    }
                    // final result in this foreach
                    if ($objectFound != null) {
                        $error = ($logic == 'update') ? false : true;
                        if (isset($objectDuplicate) && $objectDuplicate) {
                            $error = true;
                        }
                    }
                }
            } // else 
            $this->setDebug( '10 - ' . $error . ' - ' . $message );


            // groupUniqueParams
            if ($logic != 'update' && is_array($this->groupUniqueParams) && count($this->groupUniqueParams) >= 1) {
                $withUniqueParams = true;
                $finalArray = [];
                foreach ($this->groupUniqueParams as $value) {
                    $method = 'get' . ucfirst($value);
                    $finalArray[$value] = ($request != null && $request->request->get('_' . $value)) ? $request->request->get('_' . $value) : // REQUEST                                                        
                        (($arrProperties != null && is_array($arrProperties) && count($arrProperties) >= 1 && array_key_exists($value, $arrProperties)) ? // ArrayProperties
                            $arrProperties[$value] : (($object != null && $this->existMethodInObject($method)) ? $object_->$method() // Object                            
                                : false)); // Not found
                }
                $objectFound = (is_array($finalArray) && count($finalArray) >= 1) ? $this->entityManager->getRepository($repositoryName)->FindOneBy($finalArray) : $objectFound;
                if ($objectFound !== null) {
                    // $this->setError( ($logic == 'update') ? false : true);
                    $error = ($logic == 'update') ? false : true;
                }
            } // With no unique params to validate, response with no error
            // else

            if (!$withUniqueParams) {
                // $this->initializeResponse(200, false, $this->objectName . ' object without unique params to validate'); 
                $code = 200;
                $error = false;
                $message = $this->getModelName() . ' object without unique params to validate';
            }
            // with unique params to validate
            if ($objectFound != null && $this->existMethodInObject('getId', $objectFound)) { // $objectFound->getId() ) { // Found
                // To eventLog
                $this->jsonDataOld = $this->normalizeObjectFull($objectFound, 1);

                $code = 200;
                $message = $this->getModelName() . ' object found in BBDD with id: ' . $objectFound->getId();
                // For update set model
                if ($logic == 'update') {
                    $this->setModel($objectFound);
                    if ($error) {
                        $code = 400;
                        $message = (isset($messageError)) ? $messageError : $message;
                    }
                }
                // For create set in object
                else { $object = $objectFound; }
                $data['objectNormalized'] = $this->normalizeObjectFull($objectFound, 1, $this->getModelName());
            } // Found  

            // Set Response
            $this->finalResponse($code, $error, $message, $data, $object);
            $this->setDebug( json_encode([__FUNCTION__ => $this->getResponse()]) );
            $this->setDebug( 'final method: ' .  __FUNCTION__ );

        } catch (Exception $ex) {
            $this->setCode(418);
            $this->setError(true);
            $this->setMessage("Error: {$ex->getMessage()} in class: " . __CLASS__ . ", method: " . __FUNCTION__ . ", file: " . __FILE__ . ", line: " . __LINE__ .
                " Object: " . $this->getModelName());
        }
        return $this->getResponse();
    }
}
