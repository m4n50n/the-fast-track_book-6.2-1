<?php

namespace App\Model\Traits;

use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Config\Definition\Exception\Exception;
use JMS\Serializer\SerializerBuilder;
use JMS\Serializer\Serializer;
use JMS\Serializer\JsonEncoder;
use JMS\Serializer\XmlEncoder;
use phpDocumentor\Reflection\Types\Boolean;

/**
 * 
 * Trai for standard definition of responses
 * 
 * @author DigitalVirgo España
 */
trait TraitResponse
{

    /**
     * @var int https://developer.mozilla.org/es/docs/Web/HTTP/Status
     */
    protected $code = 403;

    /**
     * @var bool to define if has a problem
     */
    protected $error = true;

    /**
     * @var String with a message to the response
     */
    protected $message = 'You have no permissions to do this action'; // message to deafault 

    /**
     * @var Array with data of response
     */
    protected $data = [];

    /**
     * Deprecated
     * @var Array with data of response
     */
    protected $dataResponse = [];

    /**
     * Deprecated
     * @var Object with data of response
     */
    protected $objResponse; 

    /**
     * @var Object with data of response
     */
    protected $object; 

    /**
     * @var Array containing all properties
     */
    protected $response = [];
 
    /**
     * @return mixed
     */
    public function getCode()
    {
        return $this->code;
    }
 
    /**
     * @param mixed $code
     * @return self
     */
    public function setCode($code)
    {
        $this->code = $code; 
        return $this;
    }
 
    /**
     * @return mixed
     */
    public function getError()
    {
        return $this->error;
    }
 
    /**
     * @param mixed $error
     * @return self
     */
    public function setError(?bool $error)
    {
        $this->error = (bool) $error; 
        return $this;
    }
 
    /**
     * @return mixed
     */
    public function getMessage()
    {
        return $this->message;
    }
 
    /**
     * @param mixed $message
     * @return self
     */
    public function setMessage($message)
    {
        $this->message = $message; 
        return $this;
    }
 
    /**
     * @return mixed
     */
    public function getData()
    {
        return $this->data;
    }
 
    /**
     * @param mixed $data
     * @return self
     */
    public function setData($data)
    {
        $this->data = $data; 
        $this->dataResponse = $this->data; 
        return $this;
    }
 
    /**
     * Deprecated
     * @return mixed
     */
    public function getDataResponse()
    {
        return $this->dataResponse;
    }
 
    /**
     * Deprecated
     * @param mixed $dataResponse
     * @return self
     */
    public function setDataResponse($dataResponse)
    {
        $this->dataResponse = $dataResponse; 
        $this->data = $dataResponse; 
        return $this;
    }
 
    /**
     * @return mixed
     */
    public function getObject()
    {
        return $this->object;
    }
 
    /**
     * @param mixed $object
     * @return self
     */
    public function setObject($object)
    {
        $this->object = $object; 
        $this->objResponse = $this->object; 
        return $this;
    }
 
    /**
     * Deprecated
     * @return mixed
     */
    public function getObjResponse()
    {
        return $this->objResponse;
    }
 
    /**
     * Deprecated
     * @param mixed $objResponse
     * @return self
     */
    public function setObjResponse($objResponse)
    {
        $this->objResponse = $objResponse; 
        $this->object = $this->objResponse;
        return $this;
    }
 
    /**
     * @param mixed $response
     * @return self
     */
    public function setResponse($response)
    {
        $this->response = $response;
        $this->code = ( array_key_exists('code', $this->response ) ) ? $this->response['code'] : $this->code;
        $this->error = ( array_key_exists('error', $this->response ) ) ? $this->response['error'] : $this->error;
        $this->message = ( array_key_exists('message', $this->response ) ) ? $this->response['message'] : $this->message;
        $this->data = ( array_key_exists('data', $this->response ) ) ? $this->response['data'] : $this->data;
        $this->object = ( array_key_exists('object', $this->response ) ) ? $this->response['object'] : $this->object;
        $this->initializeResponse($this->code, $this->error, $this->message, $this->data, $this->object);
        return $this;
    }

    /**
     * Set the properties in the response correctly and return response property.
     * 
     * @return String[] the response value
     */
    public function getResponse(String $type = null)
    {
        if ( $type === 'doJsonResponse' ) {
            return $this->doJsonResponse();
        } else if ( $type === 'doSerializerBuilder' ) {
            return $this->doSerializerBuilder();
        } else if ( $type === 'doSerializer' ) {
            return $this->doSerializer();
        } else if ( $type === 'unstructure' ) {
            return $this->response = [ $this->code, $this->error, $this->message, $this->data, $this->object ];
        } else {
            return $this->response = [
                'code' => $this->code,
                'error' => $this->error,
                'message' => $this->message,
                'data' => $this->data,
                'object' => $this->object
            ];
        }
    }

    /**
     * Initialize response correctly.
     */
    public function initializeResponse(int $code = NULL, bool $error = NULL, string $message = NULL, $data = NULL, $object = NULL ) 
    {
        // $this->code = ($code !== NULL) ? $code : 403; // no permissions
        // $this->error = ($error !== NULL) ? $error : true; // error true
        // $this->message = ($message !== NULL) ? $message : 'You have no permissions to do this action'; // message to deafault
        // $this->data = ($data !== NULL) ? $data : []; // empty by default
        // $this->object = ($object !== NULL) ? $object : NULL; // empty by default
        $this->setCode(403); // no permissions
        if ($code !== NULL) { $this->setCode($code); }
        $this->setError(true); // error true
        if ($error !== NULL) { $this->setError($error); }
        $this->setMessage('You have no permissions to do this action'); //  message to deafault
        if ($message !== NULL) { $this->setMessage($message); }
        $this->setData([]); // empty by default
        if ($data !== NULL) { $this->setData($data); }
        $this->setObject(NULL); // empty by default
        if ($object !== NULL) { $this->setObject($object); }
        return $this->getResponse();
    }

    public function finalResponse(int $code = NULL, bool $error = NULL, string $message = NULL, $data = NULL, $object = NULL) {
        return $this->initializeResponse($code, $error, $message, $data, $object);
    }

    /**
     * Do JsonResponse
     */
    public function doJsonResponse(ContainerInterface $containerInterface = null ){

        if ( $containerInterface != null ) {
            if ( $this->getCode() == 200 ) {
                $containerInterface->get('logger')->info( $this->doSerializerBuilder() );
            } else if ( $this->getCode() == 400 || $this->getCode() == 401 ) {
                $containerInterface->get('logger')->warning( $this->doSerializerBuilder() );
            }
        }
        $response = new JsonResponse($this->getResponse(), $this->getCode());
        return $response;
    }

    /**
     * Do JsonResponse
     */
    public function doSerializerBuilder(){
        $serializer = SerializerBuilder::create()->build();
        return new Response($serializer->serialize($this->getResponse(), "json"), $this->getCode());
    }

    /**
     * Do JsonResponse
     */
    public function doSerializer(){
        $data = $this->convertArrayObjects($this->getResponse());
        return new JsonResponse($data, $this->getCode());
    }

    /**
     * @param mixed $data
     *
     * @return mixed
     */
    private function convertArrayObjects($data)
    {
        if ($data instanceof \ArrayObject || $data instanceof \stdClass) {
            $data = (array) $data;
        }
        if (\is_array($data)) {
            foreach ($data as $k => $v) {
                $data[$k] = $this->convertArrayObjects($v);
            }
        }
        return $data;
    }

    /**
     * set object in debugPage
     */
    public function setDebugAlarm(ContainerInterface $containerInterface = null ){
        try {
            if ( $containerInterface != null ) {
                if ( $this->getCode() == 200 ) {
                    $containerInterface->get('logger')->info( $this->doSerializerBuilder() );
                } else if ( $this->getCode() == 400 || $this->getCode() == 401 ) {
                    $containerInterface->get('logger')->warning( $this->doSerializerBuilder() );
                }
            }
        } catch (Exception $ex) {
            $this->setCode(500);
            $this->setError(true);
            $this->setMessage("Error: {$ex->getMessage()} in class: " . __CLASS__.
            ", method: " . __FUNCTION__ . ", file: " . __FILE__ . ", line: " . __LINE__);
        } return $this->getResponse();
    }
}