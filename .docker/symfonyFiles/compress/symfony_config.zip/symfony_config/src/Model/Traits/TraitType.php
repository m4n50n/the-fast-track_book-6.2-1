<?php

namespace App\Model\Traits;

use Doctrine\ORM\Mapping as ORM;

/**
 * 
 * Trait type for standar entities
 * 
 * @author DigitalVirgo España
 */
trait TraitType
{

    /**
     * @var string $type
     *
     * ORM\Column(name="type", type="string", length=100, nullable=true)
     */
    #[ORM\Column(name:"type", type: 'string', length: 100, nullable:true)]
    private $type = null;

    /**
     * @var string $subType
     *
     * @ORM\Column(name="sub_type", type="string", length=100, nullable=true)
     */
    #[ORM\Column(name:"sub_type", type: 'string', length: 100, nullable:true)]
    private $subType = null;

    /**
     * Get type
     *
     * @return string
     */
    public function getType(): ?string
    {
        return $this->type;
    }

    /**
     * Set type
     *
     * @param string $type
     */
    public function setType(?string $type): self
    {
        $this->type = $type;
        return $this;
    }

    /**
     * Get subType
     *
     * @return string
     */
    public function getSubType(): ?string
    {
        return $this->subType;
    }

    /**
     * Set subType
     *
     * @param string $subType
     */
    public function setSubType(?string $subType): self
    {
        $this->subType = $subType;
        return $this;
    }
}