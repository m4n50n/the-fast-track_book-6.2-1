<?php

namespace App\Model\Traits;

use DateTime;
use Doctrine\ORM\Mapping as ORM;

/**
 * Trait timestampable the entities
 * @author DigitalVirgo España
 */
#[ORM\HasLifecycleCallbacks()]
trait TraitTimestamp
{

    /**
     * @var datetime $createdAt
     * @ORM\Column(name="created_at", type="datetime", nullable=true)
     * 
     * Time in GMT +00:00
     */
    #[ORM\Column(name:"created_at", type: 'datetime', nullable:true)]
    private $createdAt;

    /**
     * @var datetime $updatedAt
     * @ORM\Column(name="updated_at", type="datetime", nullable=true)
     * 
     * Time in GMT +00:00
     */
    #[ORM\Column(name:"updated_at", type: 'datetime', nullable:true)]
    private $updatedAt;

    /**
     * @var string $timeZone
     * @ORM\Column(name="timeZone", type="string", nullable=true)
     * 
     * This valor is for calculate the timeZone dates
     */
    #[ORM\Column(name:"timeZone", type: 'string', nullable:true)]
    private $timeZone;

    /**
     * Get createdAt
     * @return datetime
     */
    public function getCreatedAt(): ?\DateTimeInterface
    {
        return $this->createdAt;
    }

    /**
     * Set createdAt
     * @param datetime $createdAt
     */
    public function setCreatedAt(\DateTimeInterface $createdAt = null): self
    {
        $this->createdAt = $createdAt;
        return $this;
    }

    /**
     * Get updatedAt
     * @return datetime
     */
    public function getUpdatedAt(): ?\DateTimeInterface
    {
        return $this->updatedAt;
    }

    /**
     * Set updatedAt
     * @param datetime $updatedAt
     */
    public function setUpdatedAt(\DateTimeInterface $updatedAt = null): self
    {
        $this->updatedAt = $updatedAt;
        return $this;
    }

    /**
     * Get timeZone
     * @return string
     */
    public function getTimeZone(): ?string
    {
        return $this->timeZone;
    }

    /**
     * Set timeZone
     * @param string $timeZone
     */
    public function setTimeZone(string $timeZone = null): self
    {
        $this->timeZone = $timeZone;
        return $this;
    }
 
    /**
     * @ORM\PrePersist
     */
    #[ORM\PrePersist]
    public function createTimezone()
    {
        $this->timeZone = ($this->timeZone == null) ? 'Europe/Madrid' : $this->timeZone;
    }
 
    /**
     * @ORM\PrePersist
     * @ORM\PreUpdate
     */
    #[ORM\PrePersist]
    #[ORM\PreUpdate]
    public function updatedTimestamps()
    {
        $dateTimeNow = new DateTime('now');
        $this->setUpdatedAt($dateTimeNow);
        if ($this->getCreatedAt() == null) {
            $this->setCreatedAt($dateTimeNow);
        }
    }
}