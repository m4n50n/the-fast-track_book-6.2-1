<?php

namespace App\Model\EntitiesCRUD;

use App\Model\Traits\TraitGeneralCRUD;
use App\Model\Traits\TraitResponse;

use App\Entity\EventLog;

use Exception;

/**
 * model for the CRUD actions in eventLog
 * @author DigitalVirgo España
 */
class EventLogCRUD
{
    // Respuesta estandar
    use TraitResponse;
    use TraitGeneralCRUD;

    /**
     * General initializeCRUD. this will be init personalized for the classes
     */
    public function initCRUD() {

        // Initiaze model
        $this->setModel( new EventLog() );

        // Initialize the restrictions of the fileds
        $this->setRequiredParams( ['user', 'description', 'status', 'subStatus', 'type', 'subType', 'createdAt'] );
        $this->setUniqueParams( ['createdAt'] );
        // $this->setGroupUniqueParams( [] );
        // $this->setAdviseParams( ['subStatus'] ); // not error only advise
        // $this->excludeNorm = ['eventLogs'];

        // The name of the method in the key, the param in the value
        // $this->setMethodsToValidateCreate( [ 'validateDataInMethod' ] );
        // $this->setMethodsProcessProperties( [ 'processPropertiesInMethod' ] );

        // register in evetLog by default
        $this->setRegisterEventLog( false );
    }

}