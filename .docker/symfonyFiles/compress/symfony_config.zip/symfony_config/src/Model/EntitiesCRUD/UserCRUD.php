<?php

namespace App\Model\EntitiesCRUD;

use App\Model\Traits\TraitGeneralCRUD;
use App\Model\Traits\TraitResponse;

use App\Entity\User;
use DateTime;
use Exception;
use Symfony\Component\PasswordHasher\Hasher\UserPasswordHasherInterface;

/**
 * model for the CRUD actions of the general CRUD models
 * @author DigitalVirgo España
 */
class UserCRUD
{
    // Respuesta estandar
    use TraitResponse;
    use TraitGeneralCRUD;

    protected $passwordHasher;

    /**
     * General initializeCRUD. this will be init personalized for the classes
     */
    public function initCRUD( UserPasswordHasherInterface $passwordHasher = null, User $thisUser = null ) {
        
        // for password
        $this->passwordHasher = ( $passwordHasher != null ) ? $passwordHasher : $this->passwordHasher; 

        // set user with exec action
        if ( $thisUser != null ) {
            $this->setThisUser( $thisUser );
        }

        // example for user
        $this->setModel( new User() );

        // Initialize the restrictions of the fileds
        $this->setRequiredParams( ['username', 'email', 'name'] );
        $this->setUniqueParams( ['username', 'email'] );
        $this->setGroupUniqueParams( ['username', 'email'] );
        $this->setAdviseParams( ['status'] ); // not error only advise
        $this->excludeNorm = ['eventLogs'];

        // The name of the method in the key, the param in the value
        // $this->setMethodsToValidateCreate( ['testMethod'] ); // validate only in the create method
        $this->setMethodsProcessProperties( [ 'validateUserProperties' ] ); // validate in all actions

        // register in evetLog by default
        $this->setRegisterEventLog( true );
    }

    /** 
    * Process Properties
    */

    /** Method to validateUserProperties */
    private function validateUserProperties(Array $arrayProperties = []) {
        try {
            $code = 400; $error = true; $message = 'There is an error to '.__FUNCTION__.' method'; $data = []; $object = $arrayProperties;
            $this->initializeResponse( $code, $error, $message, $data, $object );
            $this->logger->info( 'Init method: ' .  __FUNCTION__ );

            // your code to process
            if ( is_array($arrayProperties) && count($arrayProperties) >= 1 ) {

                // password
                if ( array_key_exists('plainPassword', $arrayProperties) && $arrayProperties['plainPassword'] != null ) {
                    $arrayProperties['password'] = $this->passwordHasher->hashPassword(
                        $this->model,
                        $arrayProperties['plainPassword']
                    );
                    unset($arrayProperties['plainPassword']);
                } // else { $arrayProperties['plainPassword'] = '-'; }
                // // salt
                // if ( ! array_key_exists('salt', $arrayProperties) || $arrayProperties['salt'] == null ) {
                //     $now = new DateTime('now');
                //     $arrayProperties['salt'] = md5( $now->format('Y-m-d H:i:s') . $arrayProperties['password'] );
                // }

                $data = $arrayProperties;
                $object = $arrayProperties;
                [$code, $error, $message, $data, $object] = [200, false, 'Properties process correct in ' . __FUNCTION__, $data, $object];

            } else { [$code, $error, $message, $data, $object] = [400, true, 'No params in array', $data, $object]; }

            // Set Response
            $this->finalResponse( $code, $error, $message, $data, $object );
            $typeOfDebug = ( $code == 200 ) ? 'info' : 'warning';
            $this->logger->$typeOfDebug( json_encode( [__FUNCTION__ => $this->getResponse()] ) );
            $this->logger->info( 'Final method: ' .  __FUNCTION__ );

        } catch (Exception $ex) {
            $this->setCode(418);
            $this->setError(true);
            $this->setMessage("Error: {$ex->getMessage()} in class: " . __CLASS__.", method: " . __FUNCTION__ . ", file: " . __FILE__ . ", line: " . __LINE__.
            " Object: " . $this->getModelName());
        } return $this->getResponse();
    }

    /** 
    * Validate to create
    */

    /** Method to test */
    private function testMethod(Array $arrayProperties = []) {
        try {
            $code = 400; $error = true; $message = 'There is an error to '.__FUNCTION__.' method'; $data = []; $object = [];
            $this->initializeResponse( $code, $error, $message, $data );
            $this->setDebug( 'Init method: ' .  __FUNCTION__ );        

            // your code
            if ( is_array($arrayProperties) && count($arrayProperties) >= 1 ) {

                if ( $arrayProperties['name'] == 'Antonio' ) {
                    [$code, $error, $message, $data, $object] = [200, false, 'The value '.$arrayProperties['name'].' is valid', $data, $object];
                } else {
                    [$code, $error, $message, $data, $object] = [400, true, 'The value '.$arrayProperties['name'].' is incorrect in validate method: ' . __FUNCTION__, $data, $object];
                }

            } else { [$code, $error, $message, $data, $object] = [400, true, 'No params in array', $data, $object]; }

            // Set Response
            $this->finalResponse( $code, $error, $message, $data, $object );
            $this->setDebug( json_encode( [__FUNCTION__ => $this->getResponse()] ) );

        } catch (Exception $ex) {
            $this->setCode(418);
            $this->setError(true);
            $this->setMessage("Error: {$ex->getMessage()} in class: " . __CLASS__.", method: " . __FUNCTION__ . ", file: " . __FILE__ . ", line: " . __LINE__.
            " Object: " . $this->getModelName());
        } return $this->getResponse();
    }
}