<?php

namespace App\Entity;

use App\Model\Traits\TraitStatus;
use App\Model\Traits\TraitTimestamp;
use App\Model\Traits\TraitType;
use App\Repository\EventLogRepository;
use Doctrine\DBAL\Types\Types;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity(repositoryClass: EventLogRepository::class)]
#[ORM\Table(name: '`event_log`')]
#[ORM\HasLifecycleCallbacks()]
class EventLog
{
    ### traits
    use TraitStatus;
    use TraitType;
    use TraitTimestamp;

    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column(type: 'integer')]
    private $id;

    #[ORM\ManyToOne(targetEntity: User::class)]
    #[ORM\JoinColumn(nullable: false)]
    private $user;

    #[ORM\Column(type: 'integer', nullable: true)]
    private $objectId;

    #[ORM\Column(type: 'string', length: 255, nullable: true)]
    private $description;

    #[ORM\Column(type: 'json', nullable: true)]
    private $jsonDataOld = [];

    #[ORM\Column(type: 'json', nullable: true)]
    private $jsonDataNew = [];

    #[ORM\Column(type: Types::JSON, nullable: true)]
    private $objectPropertiesChanged = [];

    /**
     * Whe use this fields for:
     * status: define the status of the action (error, correct)
     * subStatus: define the level of the response action (code, 200, 400, 401, etc...) 
     * type: define the object reference. eventLog was default
     * subType: define the action in the object
     */
    public function __construct()
    {
        $this->status = "correct";
        $this->subStatus = "200";
        $this->type = "eventLog";
        $this->subType = "system";
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getUser(): ?User
    {
        return $this->user;
    }

    public function setUser(?User $user): self
    {
        $this->user = $user;
        return $this;
    }

    public function getObjectId(): ?int
    {
        return $this->objectId;
    }

    public function setObjectId(?int $objectId): self
    {
        $this->objectId = $objectId;
        return $this;
    }

    public function getDescription(): ?string
    {
        return $this->description;
    }

    public function setDescription(?string $description): self
    {
        $this->description = $description;
        return $this;
    }

    public function getJsonDataOld(): ?array
    {
        return $this->jsonDataOld;
    }

    public function setJsonDataOld(?array $jsonDataOld): self
    {
        $this->jsonDataOld = $jsonDataOld;
        return $this;
    }

    public function getJsonDataNew(): ?array
    {
        return $this->jsonDataNew;
    }

    public function setJsonDataNew(?array $jsonDataNew): self
    {
        $this->jsonDataNew = $jsonDataNew;
        return $this;
    }

    public function getObjectPropertiesChanged(): ?array
    {
        return $this->objectPropertiesChanged;
    }

    public function setObjectPropertiesChanged(?array $objectPropertiesChanged): self
    {
        $this->objectPropertiesChanged = $objectPropertiesChanged;
        return $this;
    }
}
