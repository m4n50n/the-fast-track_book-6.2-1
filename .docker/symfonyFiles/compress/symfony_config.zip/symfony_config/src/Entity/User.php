<?php

namespace App\Entity;

use App\Model\Traits\TraitStatus;
use App\Model\Traits\TraitTimestamp;
use App\Model\Traits\TraitType;
use App\Repository\UserRepository;
// use DateTime;
use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Security\Core\User\UserInterface;
use Symfony\Component\Security\Core\User\PasswordAuthenticatedUserInterface;

// use JMS\Serializer\Annotation as Serializer;

#[ORM\Entity(repositoryClass: UserRepository::class)]
#[ORM\Table(name: '`user`')]
#[ORM\HasLifecycleCallbacks()]
class User implements UserInterface, PasswordAuthenticatedUserInterface
{
    ### traits
    use TraitStatus;
    use TraitType;
    use TraitTimestamp;

    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column(type: 'integer')]
    private $id;

    /**
     * @ORM\Column(type="string", length=255)
     */
    #[ORM\Column(type: 'string', length: 255)]
    private $name;
 
    /**
     * @ORM\Column(type="string", length=255)
     */
    #[ORM\Column(type: 'string', length: 255, unique: true)]
    private $email;
 
    /**
     * @ORM\Column(name="username", type="string", length=255, unique=true)
     */
    #[ORM\Column(type: 'string', length: 255, unique: true)]
    private $username;
 
    /**
     * @ORM\Column(name="password", type="string", length=255)
     * @Serializer\Exclude()
     */
    #[ORM\Column(type: 'string', length: 255)]
    private $password;

    /**
     * @ORM\Column(type="json_array", nullable=true)
     */
    #[ORM\Column(type: 'json', length: 255, nullable:true)]
    private $roles = [];

    /**
     * @ORM\Column(type="string", length=5, options={"default" : "en"})
     */
    #[ORM\Column(type: 'string', length: 5)]
    private $language = "en";

    public function __construct()
    {
        $this->type          = "user";
        $this->subType       = "employee";
        $this->status        = "enabled";
        $this->subStatus     = "pending";
    }
 
    /**
     * @return mixed
     */
    public function getId()
    {
        return $this->id;
    }
 
    /**
     * @return mixed
     */
    public function getName()
    {
        return $this->name;
    }
 
    /**
     * @param mixed $name
     * @return self
     */
    public function setName($name)
    {
        $this->name = $name; 
        return $this;
    }
 
    /**
     * Set email
     *
     * @param string $email
     *
     * @return User
     */
    public function setEmail($email)
    {
        $this->email = $email; 
        return $this;
    }
 
    /**
     * Get email
     *
     * @return string
     */
    public function getEmail()
    {
        return $this->email;
    }
 
    /**
     * @return mixed
     */
    public function getUsername()
    {
        return $this->username;
    }
 
    /**
     * @param mixed $username
     * @return self
     */
    public function setUsername($username)
    {
        $this->username = $username; 
        return $this;
    }
 
    /**
     * @return mixed
     */
    public function getPassword(): ?string
    {
        return $this->password;
    }
 
    /**
     * @param mixed $password
     * @return self
     */
    public function setPassword($password)
    {
        $this->password = $password; 
        return $this;
    }
    
    public function eraseCredentials() {}
    public function getUserIdentifier(): string {
        return $this->username;
        // return $this->id;
    }    

    /**
     * Get roles
     * @return array
     */
    public function getRoles(): array
    {
        return $this->roles;
    }

    /**
     * Set roles
     * @param string $roles
     * @return User
     */
    public function setRoles(?Array $roles): self
    {
        if ( getType($roles) == "array" ) {
            $this->roles = $roles;
        } else {
            $this->roles = json_decode( $roles, TRUE );
        }
        return $this;
    }

    /**
     * Add roles
     * @param string $role
     * @return User
     */
    public function addRole(?string $role): self
    {
        // if (!$this->roles->contains($role)) {
        //     $this->roles[] = $role;
        // }
        if ( ! in_array($role, $this->roles) ) {
            $this->roles[] = $role;
        }
        return $this;
    }
     
    /**
     * @ORM\PrePersist
     * @ORM\PreUpdate
     * Crete role default
     * 
     */
    #[ORM\PrePersist()]
    public function updatedRoles() {
        // add permissions default
        $this->addRole("ROLE_USER");
        $this->addRole("ROLE_" . $this->username);
        $this->addRole("ROLE_" . strtoupper($this->type));
        $this->addRole("ROLE_" . strtoupper($this->subType));
    }

    public function getLanguage(): ?string
    {
        return $this->language;
    }

    public function setLanguage(string $language): self
    {
        $this->language = $language;
        return $this;
    }
}
