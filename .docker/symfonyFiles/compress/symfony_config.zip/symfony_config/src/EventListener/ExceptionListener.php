<?php

namespace App\EventListener;

use DateTime;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpKernel\Event\ExceptionEvent;
use Symfony\Component\HttpKernel\Exception\HttpExceptionInterface;

use Exception;
use Psr\Log\LoggerInterface;
// use App\CommandHandler\BarHandler;
// use App\CommandHandler\FooHandler;
use Psr\Container\ContainerInterface;
use Symfony\Contracts\Service\ServiceSubscriberInterface;
use Doctrine\ORM\EntityManagerInterface;

use App\Model\EntitiesCRUD\EventLogCRUD;
use App\Model\Traits\TraitResponse;

// use Symfony\Component\DependencyInjection\ContainerInterface;
// use Symfony\Component\EventDispatcher\EventDispatcher;

class ExceptionListener implements ServiceSubscriberInterface
{
    // Respuesta estandar
    use TraitResponse;
    protected $logger;
    protected $entityManager;
    protected $containerInterface;

    public static function getSubscribedServices(): array
    {
        // return [
        //     'App\FooCommand' => FooHandler::class,
        //     'App\BarCommand' => BarHandler::class,
        // ];
        return [];
    }

    public function __construct(LoggerInterface $logger, EntityManagerInterface $entityManager, containerInterface $containerInterface) {
        $this->logger = $logger;
        $this->entityManager = $entityManager;
        $this->containerInterface = $containerInterface;
    }
    
    public function onKernelException(ExceptionEvent $event)
    {
        $code = 400; $error = false; $message = ''; $data = []; $response = [];
        $this->initializeResponse($code, $error, $message);

        // You get the exception object from the received event
        $exception = $event->getThrowable();
        $message = sprintf(
            'My Error says: %s with code: %s, in line: %s, in file %s, with trace: %s',
            $exception->getMessage(),
            $exception->getCode(),
            $exception->getLine(),
            $exception->getFile(),
            $exception->getTraceAsString()
        );

        $code = ( $exception->getCode() == 0 || (int) $exception->getCode() < 199 ) ? $code : $exception->getCode();
        $error = true;
        $message = $exception->getMessage();
        $data = $exception->getTrace();
        $response['file'] = $exception->getFile();
        $response['line'] = $exception->getLine();
        // $response['header'] = $event->getResponse()->headers;
        // $response['trace'] = $exception->getTraceAsString();
        // // Response
        $this->initializeResponse( $code, $error, $message, $data, $response );

        // Customize your response object to display the exception details
        // $response = new Response($message, 401, []);
        $response = new JsonResponse($this->getResponse(), $this->getCode());

        // HttpExceptionInterface is a special type of exception that
        // holds status code and header details
        if ($exception instanceof HttpExceptionInterface) {
            $response->setStatusCode($exception->getStatusCode());
            $response->headers->replace($exception->getHeaders());
        } else {
            $response->setStatusCode(Response::HTTP_INTERNAL_SERVER_ERROR);
        }
        
        // Log in debug
        $this->logger->error( json_encode( $this->getResponse() ) );

        // // https://uniwebsidad.com/libros/symfony-1-4/capitulo-17/eventos
        // $dispatcher = sfContext::getInstance()->getEventDispatcher();
        // $dispatcher->notify(new sfEvent($this, 'application.log', $this->doSerializerBuilder()));
        // $dispatcher = new EventDispatcher();
        // echo '<pre>';
        // print_r( $dispatcher-> getListeners('application.log') );
        // echo '</pre>';
        // $dispatcher->notify(new sfEvent($this, 'application.log', $this->doSerializerBuilder()));

        // setRegister in eventLog
        $user = null;
        if ( $user == null ) {
            $user = $this->entityManager->getRepository('App\Entity\User')->findOneBy( ['username' => 'admin'] );
        }
        if ( $user != null ) {
            $dateTimeNow = new DateTime('now');
            $arrProperties = [
                'user' => $user,
                'objectId' => null,
                'description' => $this->getMessage(),
                'jsonDataOld' => $this->getData(),
                'jsonDataNew' => $this->getObject(),
                // 'objectPropertiesChanged' => $this->getObjectPropertiesChanged($jsonDataOld, $jsonDataNew),
                'status' => ($this->getError()) ? 'error' : 'correct', // * status: define the status of the action (error, correct)
                'subStatus' => $this->getCode(), // * subStatus: define the level of the response action (code, 200, 400, 401, etc...)
                'type' => 'EventLog', // * type: define the entityName. eventLog was default
                'subType' => 'unknow', // * subType: define the action in the object
                'createdAt' => $dateTimeNow,
                // 'updatedAt' => new DateTime('now'),
                'timeZone' => ''
            ];
            $eventLogCRUD = new EventLogCRUD($this->entityManager, $this->logger);
            $eventLogCRUD->initCRUD();
            $this->setResponse( $eventLogCRUD->create(null, $arrProperties, null) );
        }
        
        // sends the modified response object to the event
        $event->setResponse($response);
        // $this->log( $event->getException() );
        // $this->log( $exception );
    }
 
    /** 
     * DEPRECATED 
     */

    /** log */
    private function log($exception) {
        $log = [
            'code' => $exception->getStatusCode(),
            'message' => $exception->getMessage(),
            'called' => [
                'file' => $exception->getTrace()[0]['file'],
                'line' => $exception->getTrace()[0]['line'],
            ],
            'occurred' => [
                'file' => $exception->getFile(),
                'line' => $exception->getLine(),
            ],
        ];
 
        if ($exception->getPrevious() instanceof Exception) {
            $log += [
                'previous' => [
                    'message' => $exception->getPrevious()->getMessage(),
                    'exception' => get_class($exception->getPrevious()),
                    'file' => $exception->getPrevious()->getFile(),
                    'line' => $exception->getPrevious()->getLine(),
                ],
            ];
        } 
        $this->logger->error( json_encode($log) );
    }
}