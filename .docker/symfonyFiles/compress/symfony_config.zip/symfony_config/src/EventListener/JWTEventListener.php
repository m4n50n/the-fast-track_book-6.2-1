<?php

namespace App\EventListener;

use App\Entity\Group;
use Lexik\Bundle\JWTAuthenticationBundle\Event\JWTCreatedEvent;
use Lexik\Bundle\JWTAuthenticationBundle\Event\JWTDecodedEvent;
// use Symfony\Component\DependencyInjection\ContainerInterface;
use Symfony\Component\HttpFoundation\RequestStack;
// use Symfony\Component\Config\Definition\Exception\Exception;
use Doctrine\ORM\EntityManagerInterface;

use App\Entity\User;
use App\Model\Traits\TraitResponse;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

/**
 *
 */
class JWTEventListener extends AbstractController
{
    // Respuesta estandar
    use TraitResponse;
    
    /**
    * @var RequestStack
    */
    private $requestStack;
    protected $doctrine;
    public function setDoctrine($doctrine) {
        $this->doctrine = $doctrine;
        return $this;
    }
    // protected $doctrine;
    protected $entityManager;
    protected $containerInterface;

    /** @param RequestStack $requestStack */
    public function __construct(RequestStack $requestStack, EntityManagerInterface $entityManager)
    {
        $this->requestStack = $requestStack;
        // $this->containerInterface = $containerInterface;
        $this->containerInterface = $this->container;
        // $this->doctrine = ( !$entityManager instanceof EntityManagerInterface ) ? $entityManager : null;
        // $this->entityManager = ( $entityManager instanceof EntityManagerInterface ) ? $entityManager : $this->doctrine->getManager();
        $this->entityManager = $entityManager;
    }

    /**
    * @param JWTCreatedEvent $event
    * @return void
    */
    public function onJWTCreated(JWTCreatedEvent $event ) {
        $request = $this->requestStack->getCurrentRequest();
        $thisUser = new User();
        // if ( $event->getUserToJWT() !== null ) { $thisUser = $event->getUserToJWT();}
        if ( $event->getUser() !== null ) {
            // $thisUser = $event->getUser()->getUsername();
            $thisUser = $this->entityManager->getRepository('App\Entity\User')->FindOneBy( ['username' => $event->getUser()->getUsername()] );
        }

        // Body
        $payload = $event->getData();
        // $expiration = new \DateTime('+1 hour');
        // $expiration->setTime(2, 0, 0);
        // $payload['exp'] = $expiration->getTimestamp();
        
        $payload['ip'] = $request->getClientIp();
        $payload['name'] = $thisUser->getName();
        $payload['admin'] = ($thisUser->getType() == 'admin') ? true : false;
        
        // Set Response
        $event->setData($payload);
        
        // Header
        // $header        = $event->getHeader();
        // $header['cty'] = 'JWT';
        // $event->setHeader($header);
    }
    
    // /**
    //  * @param JWTDecodedEvent $event
    //  * @return void
    //  */
    // public function onJWTDecoded(JWTDecodedEvent $event) {
    //     $request = $this->requestStack->getCurrentRequest();
        
    //     $payload = $event->getPayload();
    
    //     if (!array_key_exists('ip', $payload) || $payload['ip'] !== $request->getClientIp()) {
    //         $event->markAsInvalid();
    //     }
    // }

    /**
     * ******************
     * ***  Get data  ***
     * ******************
     */
}