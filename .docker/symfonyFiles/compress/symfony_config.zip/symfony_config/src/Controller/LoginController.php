<?php

namespace App\Controller;

use Symfony\Component\Routing\Annotation\Route;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
// use Swagger\Annotations as SWG;
use OpenApi\Annotations as OA;
// use Sensio\Bundle\FrameworkExtraBundle\Configuration\ParamConverter;

use Symfony\Component\HttpFoundation\Request;
use Psr\Log\LoggerInterface;
use Doctrine\Persistence\ManagerRegistry;
use Lexik\Bundle\JWTAuthenticationBundle\Services\JWTTokenManagerInterface;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Security;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\IsGranted;
// use Symfony\Component\DependencyInjection\ContainerInterface;
// use Psr\Container\ContainerInterface;
// use Symfony\Component\Security\Core\Authentication\Token\TokenInterface;


// use App\Entity\EventLog;
// use App\Service\EntitiesCRUD\EventLogCRUD;
use Namshi\JOSE\JWS;
use Symfony\Component\PasswordHasher\Hasher\UserPasswordHasherInterface;
use JMS\Serializer\Exception\Exception;

use Symfony\Component\Serializer\Encoder\JsonEncoder;
use Symfony\Component\Serializer\Encoder\XmlEncoder;
use Symfony\Component\Serializer\Normalizer\ObjectNormalizer;
use Symfony\Component\Serializer\Serializer;

use App\Entity\User;
use App\Model\EntitiesCRUD\UserCRUD;
use App\Model\Traits\TraitResponse;
use App\Service\Utilities\ProcessRequest;

/**
 * Class LoginController
 * @Route("/api")
 */
class LoginController extends AbstractController
{
    // Respuesta estandar
    use TraitResponse;
    
    /**
     *             _ _______    _              
     *            | |__   __|  | |             
     *   __ _  ___| |_ | | ___ | | _____ _ __  
     *  / _` |/ _ \ __|| |/ _ \| |/ / _ \ '_ \ 
     * | (_| |  __/ |_ | | (_) |   <  __/ | | |
     *  \__, |\___|\__||_|\___/|_|\_\___|_| |_|
     *   __/ |                                 
     *  |___/                                  
     */

    /** Get a jwt with a login.
     * This call get a jwt for use in the app.
     * You must send a correct username and password or a correct token asociated to your username send.
     * 
     * @OA\Tag(name="Login")
     * @Route("/login/token", name="login_token", methods={"POST"})
     *
     * @OA\Response( response=200, description="User was logged in successfully" )
     * @OA\Response( response=500, description="User was not logged in successfully" )
     * 
     * @OA\Parameter( name="_username", in="query", form="true", required=true, description="The username", schema={} )
     * @OA\Parameter(name="_token", in="query", form="true", description="The token for the user", schema={} )
     * @OA\Parameter(name="_password", in="query", form="true", description="The password", schema={} )
     * 
     */
    public function getLoginCheckActionToken(Request $request, LoggerInterface $logger, ManagerRegistry $doctrine, UserPasswordHasherInterface $passwordHasher, JWTTokenManagerInterface $JWTManager) {
        try { 
            $code = 400; $error = true; $message = 'Method '.__FUNCTION__.' exec with no actions'; $data = []; $object = [];
            $this->initializeResponse($code, $error, $message, $data, $object);
            $request = ProcessRequest::processRequest($request);
            // $containerInterface = $this->container; 
            $entityManager = $doctrine->getManager();
            $logger->info( 'Init in class: ' . __CLASS__ . " method: " . __FUNCTION__ );
            
            $username = null;
            $userId = null;
            $type = 'unknown';
            $valueOd = null;
            $valueNew = null;
            $validToken = ( $this->container->has('token.actions_manual') ) ? $this->getParameter('token.actions_manual') : '2e89b2133ea6d4d64916a2f23899182f';
            if ( $request->request->get('_username') ) { // Error 1
                $username = $request->request->get('_username');
                $user = $doctrine->getManager()->getRepository('App\Entity\User')->findOneBy( ['username' => $username, 'status' => 'enabled'] );
                // $user = ($user == null) ? $entityManager->getRepository('App\Entity\User')->findOneBy(['code' => $username, 'status' => 'enabled']) : $user;
                // $user = ($user == null) ? $entityManager->getRepository('App\Entity\User')->findOneBy(['id' => $username, 'status' => 'enabled']) : $user;
                
                if ( $user != null ) { // Error 2
                    $username = $user->getUsername();
                    $userId = $user->getId();
                    if ( $user->getStatus() !== 'disabled' ) { // Error 3

                        if ( $request->request->has('_password') ) { // By password  // Error 4
                            $type = 'password';
                            // $encoder = $this->container->get('security.authorization_checker'); // getSubscribedServices ()                 
                            if ( $passwordHasher->isPasswordValid($user, $request->request->get('_password')) ) {
                                $this->setCode(200); $this->setError(false); $this->setMessage("Password correct");
                            } else { $this->setMessage("Password incorrect"); }
                        }
                        else if ( $request->request->has('_token') ) { // By token  // Error 4
                            $type = 'token';
                            $token = $request->request->get('_token');
                            // getCode() ?? if is an agent to Voz -> else error
                            if ( $user->getCode() != null ) { // Error 5

                                if ( $token == $validToken ) { //'927b205c9befbdce8af27fdc812b0edf' ) {  // Error 6
                                    $this->setCode(200); $this->setError(false); $this->setMessage("Token correct");
                                } else if ( count(explode('.', $token)) === 3 ) {  // Error 6
                                    $isBase64 = true;
                                    $tokenParts = explode('.', $token);
                                    $tokenHead = json_decode(base64_decode($tokenParts[0]), TRUE);
                                    $tokenPayload = json_decode(base64_decode($tokenParts[1]), TRUE);
                                    $tokenCode = $tokenParts[2];
                                    $isBase64 = ( $isBase64 && is_array($tokenHead) ) ? $isBase64 : false;
                                    $isBase64 = ( $isBase64 && array_key_exists('alg', $tokenHead) && $tokenHead['alg'] === 'HS256' ) ? $isBase64 : false;
                                    $isBase64 = ( $isBase64 && array_key_exists('typ', $tokenHead) && $tokenHead['typ'] === 'JWT' ) ? $isBase64 : false;
                                    $isBase64 = ( $isBase64 && is_array($tokenPayload) ) ? $isBase64 : false;
                                    $isBase64 = ( $isBase64 && array_key_exists('id', $tokenPayload) ) ? $isBase64 : false;
                                    $isBase64 = ( $isBase64 && array_key_exists('iat', $tokenPayload) ) ? $isBase64 : false;
                                    $isBase64 = ( $isBase64 && array_key_exists('exp', $tokenPayload) ) ? $isBase64 : false;

                                    if ( $isBase64 ) { // Error 7
                                        // The class to validate JWT from frontEnd
                                        $jws            = JWS::load($token);
                                        $public_key_DEV = "pyKODPfZibvG9FFNuzRlCOVxUsmetVBc";
                                        $public_key_PRO = "q7rrGlue8lyo35Fch6R6qSbO1OLEmfuI";
                                        $publicKeyToken = ( $this->container->has('voz.public_key_token') ) ? $this->getParameter('voz.public_key_token') : $public_key_DEV;
                                        if ( $publicKeyToken != false ) { // error 8
                                            $algo = 'HS256';
                                            // verify that the token is valid
                                            if ($jws->verify($publicKeyToken, $algo)) { // Error 9
                                                $payload = $jws->getPayload();
                                                if ( $payload['exp'] > microtime(TRUE) ) { // Error 10
                                                    $agentId = $payload['id'];
                                                    if ( $agentId == $user->getCode() ) { // Error 11
                                                        
                                                        // // Free user to Voz TODO: revisar si dejamos o quitamos esto
                                                        // $this->setMessage( $this->freeTicketForUserLoged($user->getPin(), $this->container) );
                                                        // if ( !$this->getError() ) {
                                                        //     $this->setCode(200); $this->setError(false); $this->setMessage("Token correct");
                                                        //     $valueOld = array("tokenVoz" => $token);
                                                        // }                                                        
                                                        $this->setCode(200); $this->setError(false); $this->setMessage("Token correct");
                                                        $valueOld = array("tokenVoz" => $token);

                                                    } else { $this->setMessage("No data credential for this user JWT"); } // Error 11
                                                } else { $this->setMessage("Token expired"); } // Error 10
                                            } else { $this->setMessage("No data correct to set login with this token"); } // Error 9
                                        } else { $this->setMessage("No public key Voz token for this action"); } // Error 8                                        
                                    } else { $this->setMessage("JWT format no correct"); } // Error 7
                                } else { $this->setMessage("JWT format incorrect"); } // Error 6
                            } else { $this->setMessage("No data correct to set login for this user without code"); } // Error 5
                        } else { $this->setMessage("No data correct to set login"); } // Error 4
                    } else { $this->setMessage("No user enabled for this credentials"); } // Error 3
                } else { $this->setMessage("User no exist: " . $username); } // Error 2
            } else { $this->setMessage("No get username"); } // Error 1
            // Init EventLogCRUD
            // $eventLogCRUD = new EventLogCRUD($entityManager, $this->container, new EventLog(), "EventLog");
            // $eventLogCRUD->initializeCRUD();
            $arrProperties = array( 'objectId' => $userId, 'user' => 1, 'action' => 'loginToken', 'description' => $username . ' - ' . $this->getMessage(),
                'type' => $type, 'subType' => '0', 'createdLocalAt' => ($request->request->get('_createdLocalAt')) ? $request->request->get('_createdLocalAt') : null );
            if ( isset($valueOld) && $valueOld != null ) { $arrProperties['jsonDataOld'] = $valueOld; }
            // good response with TOKEN
            if ( !$this->getError() ) { // Error
                // $jwtManager = $this->container->get('lexik_jwt_authentication.jwt_manager');
                // $tokenToSend = $jwtManager->create($user);
                // $jwtManager = $this->container->get('lexik_jwt_authentication.handler.authentication_success');
                // $tokenToSend = $jwtManager->create($user);
                $tokenToSend = $JWTManager->create($user);

                $encoders = [new XmlEncoder(), new JsonEncoder()];
                $normalizers = [new ObjectNormalizer()];
                ### https://symfony.com/doc/current/components/serializer.html
                $serializer = new Serializer($normalizers, $encoders);
                // $object = $serializer->serialize($user, 'json');

                [$code, $error, $message, $data, $object] = [200, false, "get token correct", $serializer->serialize($user, 'json'), $tokenToSend];

                // $this->setData( ['token' => $tokenToSend] );
                // $this->setCode( 200 );
                // $arrProperties['user'] = $user;
                // $arrProperties['subType'] = '1';
                // $arrProperties['jsonDataNew'] = array("tokenCuscare" => $tokenToSend);
                // eventLog OK
                // $eventLogCRUD->create(null, $arrProperties);

            } else { // EventLog ERROR                
                // $eventLogCRUD->setResponse( $this->getResponse() );
                // $eventLogCRUD->setEventLOG( 'loginToken' );
            }

            // response
            $this->initializeResponse($code, $error, $message, $data, $object);
            $logger->info( json_encode( $this->getResponse() ) );
            $logger->info( 'Final in class: ' . __CLASS__ . " method: " . __FUNCTION__ );

        } catch (Exception $ex) {
            $this->setCode(500);
            $this->setError(true);
            $this->setMessage("Error: {$ex->getMessage()} in class: " . __CLASS__.
            ", method: " . __FUNCTION__ . ", file: " . __FILE__ . ", line: " . __LINE__);
        } return $this->doJsonResponse();
    }

    /**
     *             _ _     _       _       _                 _       
     *            | (_)   | |     | |     | |               (_)      
     * __   ____ _| |_  __| | __ _| |_ ___| |     ___   __ _ _ _ __  
     * \ \ / / _` | | |/ _` |/ _` | __/ _ \ |    / _ \ / _` | | '_ \ 
     *  \ V / (_| | | | (_| | (_| | ||  __/ |___| (_) | (_| | | | | |
     *   \_/ \__,_|_|_|\__,_|\__,_|\__\___|______\___/ \__, |_|_| |_|
     *                                                  __/ |        
     *                                                 |___/        
     */

    /** 
     * Get auth.
     * 
     * Get auth with password
     * 
     * @OA\Tag(name="Login")
     * @Route("/login/checkJWT", name="login_checkjwt", methods={"POST"})
     * @IsGranted("ROLE_USER", message="You dont have permissions to do this action", statusCode=401)
     *
     * @OA\Response( response=200, description="User was logged in successfully" )
     * @OA\Response( response=500, description="User was not logged in successfully" )
     * 
     * @OA\Parameter(name="authorization", in="header", required=true, description="passing JWT from headers" )
     * 
     */
    public function checkJWT(Request $request, LoggerInterface $logger) {
        try {
            $code = 200; $error = false; $message = 'Action executed without actions'; $data = []; $object = [];
            $this->initializeResponse($code, $error, $message);
            $request = ProcessRequest::processRequest($request);
            // $containerInterface = $logger; 
            // $entityManager = $doctrine->getManager();
            // $entityManager = $this->getManager();
            $logger->info( 'Init in class: ' . __CLASS__ . " method: " . __FUNCTION__ );
            
            $data['requestAll'] = $request->request->all();
            $data['getContent'] = $request->getContent();
            $data['requestAll'] = $request->request->all();

            if ( $this->container->get('security.authorization_checker')->isGranted( 'ROLE_USER' ) ) {
                $data['granted'] = true;
            } 
            else {
                $data['granted'] = false;
            }
            
            if ( $this->getUser() != null ) {

                $encoders = [new XmlEncoder(), new JsonEncoder()];
                $normalizers = [new ObjectNormalizer()];
                ### https://symfony.com/doc/current/components/serializer.html
                $serializer = new Serializer($normalizers, $encoders);
                $object = $serializer->serialize($this->getUser(), 'json');

                [$code, $error, $message, $data, $object] = [200, false, 'Login valid with token', $data, $object];

            } else { [$code, $error, $message, $data, $object] = [400, true, 'No get user valid', $data, []]; }
            
            // set response
            $this->initializeResponse($code, $error, $message, $data, $object); 
            $logger->info( json_encode( ['response' => $this->getResponse()] ) );
            $logger->info( 'Final in class: ' . __CLASS__ . " method: " . __FUNCTION__ );

        } catch (Exception $ex) {
            $this->setCode(500);
            $this->setError(true);
            $this->setMessage("Error: {$ex->getMessage()} in class: " . __CLASS__.
            ", method: " . __FUNCTION__ . ", file: " . __FILE__ . ", line: " . __LINE__);
        } return $this->doJsonResponse();
    }

    /** 
     * Get auth.
     * 
     * Get auth with password
     * 
     * @OA\Tag(name="Login")
     * @Route("/login/auth", name="login_auth", methods={"POST"})
     *
     * @OA\Response( response=200, description="User was logged in successfully" )
     * @OA\Response( response=500, description="User was not logged in successfully" )
     *
     * @OA\Parameter(name="_username", in="query", form="true", required=true, description="The username", schema={} )
     * @OA\Parameter(name="_password", in="query", form="true", required=true, description="The password", schema={} )
     */
    public function getAuth(Request $request, LoggerInterface $logger, ManagerRegistry $doctrine, UserPasswordHasherInterface $passwordHasher) {
        try {
            $code = 200; $error = false; $message = 'Action executed without actions'; $data = []; $object = [];
            $this->initializeResponse($code, $error, $message);
            $request = ProcessRequest::processRequest($request);
            // $containerInterface = $logger; 
            $entityManager = $doctrine->getManager();
            // $entityManager = $this->getManager();
            $logger->info( 'Init in class: ' . __CLASS__ . " method: " . __FUNCTION__ );
            
            $data['requestAll'] = $request->request->all();
            $data['getContent'] = $request->getContent();
            // $data['_SERVER'] = $_SERVER;

            // required
            $processRequest = new ProcessRequest( $doctrine, $logger );
            // $processRequest->__construct0( $doctrine, $logger );
            $this->setResponse( $processRequest->requiredGeneralParams($request, ['_username', '_password']) );
            if ( !$this->getError() ) {

                $userFound = $entityManager->getRepository('App\Entity\User')->findOneBy( ["username" => $request->request->get('_username')] );
                if ( $userFound != null ) {
                    // $hashedPassword = $passwordHasher->hashPassword( $userFound, $request->request->get('_password') );
                    if ( $passwordHasher->isPasswordValid( $userFound, $request->request->get('_password') ) ) {

                        $encoders = [new XmlEncoder(), new JsonEncoder()];
                        $normalizers = [new ObjectNormalizer()];
                        ### https://symfony.com/doc/current/components/serializer.html
                        $serializer = new Serializer($normalizers, $encoders);
                        $object = $serializer->serialize($userFound, 'json');
                        // $jsonContent contains {"name":"foo","age":99,"sportsperson":false,"createdAt":null}                    
                        // echo $jsonContent; // or return it in a Response
                        [$code, $error, $message, $data, $object] = [200, false, 'User logged correct', $data, $object];

                    } else { [$code, $error, $message] = [400, true, 'Password incorrect']; }

                } else { [$code, $error, $message] = [400, true, 'User not found']; }

            }
            $request->request->set('_password', '*****');
            $data['requestAll'] = $request->request->all();
            $content = json_decode($request->getContent(), TRUE);
            foreach ($content as $keyContent => $valueContent) {
                if ( $keyContent == '_password' ) {
                    $content[$keyContent] = '*****';
                }
            }
            $data['getContent'] = json_encode( $content );
            
            // set response
            $this->initializeResponse($code, $error, $message, $data, $object); 
            $logger->info( json_encode( ['response' => $this->getResponse()] ) );
            $logger->info( 'Final in class: ' . __CLASS__ . " method: " . __FUNCTION__ );

        } catch (Exception $ex) {
            $this->setCode(500);
            $this->setError(true);
            $this->setMessage("Error: {$ex->getMessage()} in class: " . __CLASS__.
            ", method: " . __FUNCTION__ . ", file: " . __FILE__ . ", line: " . __LINE__);
        } return $this->doJsonResponse();
    }
    
    /** 
     * Create admin user.
     * We have to create an admin initial user with ths endpoint
     * 
     * @OA\Tag(name="Login")
     * @Route("/login/adminUser", name="login_admin_user", methods={"POST"})
     *
     * @OA\Response( response=200, description="User was logged in successfully" )
     * @OA\Response( response=500, description="User was not logged in successfully" )
     * 
     * @OA\Parameter( name="_name", in="query", required=false, description="The param value", schema={} )
     * @OA\Parameter( name="_email", in="query", required=false, description="The param value", schema={} )
     * @OA\Parameter( name="_username", in="query", required=false, description="The param value", schema={} )
     * @OA\Parameter( name="_password", in="query", description="The password", schema={} )
     * @OA\Parameter( name="_roles", in="query", required=false, description="The param value", schema={} )
     * @OA\Parameter( name="_language", in="query", required=false, description="The param value", schema={} )
     * @OA\Parameter( name="_groups", in="query", required=false, description="The param value", schema={} )
     * @OA\Parameter( name="_role_default", in="query", required=false, description="The param value", schema={} )
     * @OA\Parameter( name="_country", in="query", required=false, description="The param value", schema={} )
     * @OA\Parameter( name="_type", in="query", required=false, description="The param value", schema={} )
     * @OA\Parameter( name="_sub_type", in="query", required=false, description="The param value", schema={} )
     * @OA\Parameter( name="_status", in="query", required=false, description="The param value", schema={} )
     * @OA\Parameter( name="_subStatus", in="query", required=false, description="The param value", schema={} )
     * @OA\Parameter( name="_clientId", in="query", required=false, description="The param value", schema={} )
     * @OA\Parameter( name="_clienttype", in="query", required=false, description="The param value", schema={} )
     * @OA\Parameter( name="_clientfatherid", in="query", required=false, description="The param value", schema={} )
     * 
     * @OA\Parameter( name="_created_at", in="query", required=false, description="The param value", schema={} )
     * @OA\Parameter( name="_created_local_at", in="query", required=false, description="The param value", schema={} )
     * @OA\Parameter( name="_updated_at", in="query", required=false, description="The param value", schema={} )
     */
    public function setAdminUser(Request $request, LoggerInterface $logger, ManagerRegistry $doctrine, UserPasswordHasherInterface $passwordHasher) {
        try {
            $code = 200; $error = false; $message = 'Action executed without actions'; $data = []; $object = [];
            $this->initializeResponse($code, $error, $message);
            $request = ProcessRequest::processRequest($request);
            // $containerInterface = $logger; 
            $entityManager = $doctrine->getManager();
            // $entityManager = $this->getManager();
            $logger->info( 'Init in class: ' . __CLASS__ . " method: " . __FUNCTION__ );
            
            $data['requestAll'] = $request->request->all();
            $data['getContent'] = $request->getContent();
            // $data['_SERVER'] = $_SERVER;

            $userAdmin = $entityManager->getRepository('App\Entity\User')->findOneBy( ["username" => "admin"] );
            if ( $userAdmin == null ) {
                // required
                $processRequest = new ProcessRequest( $doctrine, $logger );
                // $processRequest->__construct0( $doctrine, $logger );
                $this->setResponse( $processRequest->requiredGeneralParams($request, ['_username', '_email', '_plainPassword', '_name']) );
                if ( !$this->getError() ) {

                    $userAdmin = new User();
                    $password = $passwordHasher->hashPassword(
                        $userAdmin,
                        $request->request->get('_plainPassword')
                    );

                    // object
                    $userAdmin->setName( $request->request->get('_name') );
                    $userAdmin->setEmail( $request->request->get('_email') );
                    $userAdmin->setUsername( $request->request->get('_username') );
                    // $userAdmin->setSalt( md5( $request->request->get('_username') . microtime() ) );
                    $userAdmin->setPassword( $password );
                    $userAdmin->setRoles( ['ROLE_USER'] );
                    $userAdmin->setLanguage( 'es' );
                    // $userAdmin->setCountry( 'es' );
                    $userAdmin->setType( 'admin' );
                    $userAdmin->setSubType( 'user' );
                    $userAdmin->setStatus( 'enabled' );
                    $userAdmin->setSubStatus( 'enabled' );

                    // // with no log
                    // $entityManager->persist( $userAdmin );
                    // $entityManager->flush();

                    // with array
                    $userData = [
                        'name' => $request->request->get('_name'),
                        'email' => $request->request->get('_email'),
                        'username' => $request->request->get('_username'),
                        'password' => $password,
                        'roles' => ['ROLE_USER'],
                        'language' => 'es',
                        'country' => 'es',
                        'type' => 'admin',
                        'subType' => 'user',
                        'status' => 'enabled',
                        'subStatus' => 'enabled'
                    ];

                    // with userCRUD START
                    $userCRUD = new UserCRUD($doctrine, $logger);
                    $userCRUD->initCRUD( $passwordHasher ); // special for user because we have to has the password
                    
                    $this->setResponse( $userCRUD->create( null, $userData, $userAdmin) );
                    [$code, $error, $message, $data, $object] = $this->getResponse('unstructure');
                    if ( !$this->getError() ) {

                        // $userSerialized = $userCRUD->normalizeObjectFull( $this->getObject(), 2 );
                        // $object = $userSerialized;
                        $object = $userCRUD->serializer->serialize( $this->getObject(), 'json' );
                        [$code, $error, $message, $data, $object] = [200, false, 'User admin created', $data, $object];

                    } // else { [$code, $error, $message, $data, $object] = $this->getResponse('unstructure'); }
                    // with userCRUD END

                } else { [$code, $error, $message, $data_, $object_] = $this->getResponse('unstructure'); }
            } else { [$code, $error, $message, $data, $object] = [400, true, 'User admin exist', $data, $object]; }

            // set response
            $this->initializeResponse($code, $error, $message, $data, $object); 
            $logger->info( json_encode( ['response' => $this->getResponse()] ) );
            $logger->info( 'Final in class: ' . __CLASS__ . " method: " . __FUNCTION__ );

        } catch (Exception $ex) {
            $this->setCode(500);
            $this->setError(true);
            $this->setMessage("Error: {$ex->getMessage()} in class: " . __CLASS__.
            ", method: " . __FUNCTION__ . ", file: " . __FILE__ . ", line: " . __LINE__);
        } return $this->doJsonResponse();
    }

    /**
     *      _       __            _ _   _                 _       __  __      _   _               _ 
     *     | |     / _|          | | | | |               (_)     |  \/  |    | | | |             | |
     *   __| | ___| |_ __ _ _   _| | |_| |     ___   __ _ _ _ __ | \  / | ___| |_| |__   ___   __| |
     *  / _` |/ _ \  _/ _` | | | | | __| |    / _ \ / _` | | '_ \| |\/| |/ _ \ __| '_ \ / _ \ / _` |
     * | (_| |  __/ || (_| | |_| | | |_| |___| (_) | (_| | | | | | |  | |  __/ |_| | | | (_) | (_| |
     *  \__,_|\___|_| \__,_|\__,_|_|\__|______\___/ \__, |_|_| |_|_|  |_|\___|\__|_| |_|\___/ \__,_|
     *                                               __/ |                                          
     *                                              |___/                                           
     */

    /** 
     * Get a jwt with a login.
     * 
     * This call get a jwt for use in the app.
     * You must send a correct username and password.
     * 
     * @OA\Tag(name="Login")
     * @Route("/login", name="login", methods={"POST"})
     *
     * @OA\Response( response=200, description="User was logged in successfully" )
     * @OA\Response( response=500, description="User was not logged in successfully" )
     *
     * @OA\Parameter(name="username", in="query", required=true, description="The username", schema={} )
     * @OA\Parameter(name="password", in="query", required=true, description="The password", schema={} )
     */
    public function getLoginCheckAction() {}

}