<?php

namespace App\Controller;

use DateInterval;
use DateTime;
use DateTimeZone;
use Symfony\Component\Validator\Constraints\Timezone;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Routing\Annotation\Route;

use Doctrine\Persistence\ManagerRegistry;
use Psr\Log\LoggerInterface;

use Symfony\Component\Config\Definition\Exception\Exception;
use Symfony\Component\HttpFoundation\Request;
// use Swagger\Annotations as SWG;
use OpenApi\Annotations as OA;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\IsGranted;
use Symfony\Component\PasswordHasher\Hasher\UserPasswordHasherInterface;

use App\Model\Traits\TraitResponse;
use App\Service\Utilities\ProcessRequest;

use App\Entity\User;
// use App\Model\EntitiesCRUD\GeneralCRUD;
use App\Model\EntitiesCRUD\EventLogCRUD;
use App\Model\EntitiesCRUD\UserCRUD;

/**
 * Class TestController
 * @Route("/api")
 *
 * This route (api/test) may be declared in the security.yml with permissions
 */
class TestController extends AbstractController
{
    // Respuesta estandar
    use TraitResponse;

    /**
     * EXAMPLES
     */

    /** Example method to update an user with request params.
     * This method will be a example to update a controller endpoint for actions in app.
     * You must send the params required and the format correct to update an user.
     * 
     * @OA\Tag(name="Test")
     * @Route("/test/setMultipleUser", name="test_setMultipleUser", methods={"POST"})
     * @IsGranted("ROLE_STANDARD", message="You dont have permissions to do this action", statusCode=401)
     * @OA\Response( response="default", description="An 'unexpected' error." )
     *
     * @OA\Parameter( in="header", name="authorization", required=true, description="passing JWT from headers" )
     *
     * @OA\Parameter(name="_username", in="query", required=true, description="The param username")
     * @OA\Parameter(name="_password", in="query", required=false, description="The param password")
     * @OA\Parameter(name="_name", in="query", required=false, description="The param name")
     * @OA\Parameter(name="_email", in="query", required=false, description="The param email")
     */
    public function setMultipleUserRequest(Request $request, LoggerInterface $logger, ManagerRegistry $doctrine, UserPasswordHasherInterface $passwordHasher, Bool $returnArray = false) {
        try {
            $code = 400; $error = true; $message = 'No get params to do action in ' . __FUNCTION__; $data = []; $object = [];
            $this->initializeResponse( $code, $error, $message );
            if ( ! $returnArray ) {  $request = ProcessRequest::processRequest($request); }
            $entityManager = $doctrine->getManager();
            $logger->info( 'Init method ' . __FUNCTION__ );

            // debug get request
            $data['request'] = $request->request->all();

            // required params
            $processRequest = new ProcessRequest( $entityManager, $logger );
            $this->setResponse( $processRequest->requiredParams($request, ['_userObject']) );
            if ( !$this->getError() ) {

                $userObject_ = $request->request->get('_userObject');
                $userObject = ( getType($userObject_) == 'string' ) ? json_decode($userObject_, true) : (( getType($userObject_) == 'array' ) ? $userObject_ : null );
                $data['_userObject'] = $userObject;

                $data['userParams'] = [];
                foreach (get_class_methods(new User()) as $valueMethod) {
                    if ( substr($valueMethod, 0, 3) == 'get' ) {
                        $data['userParams'][] = lcfirst(str_replace('get', '', $valueMethod));
                    }
                }
                $request->request->remove( '_userObject' );

                foreach ($userObject as $valueUserObject) {
                    $actionResult = [];
                    $action = ( array_key_exists('id', $valueUserObject) && $valueUserObject['id'] != null ) ? 'updateUserRequest' : 'createUserRequest';
                    $request->request->set( 'action', $action );
                    
                    // clean userParams in request
                    foreach ($data['userParams'] as $valueParam) {
                        if ( $request->request->has( '_' .  $valueParam ) ) {
                            $request->request->remove( '_' .  $valueParam );
                        }
                    }
                    foreach ($valueUserObject as $keyUser => $valueUser) {
                        $request->request->set( '_' . $keyUser, $valueUser );
                    }
                    // set action
                    $data['requestSet'][] = $request->request->all();
                    $logger->info( json_encode( ['action' => $action, 'request' => $request->request->all()] ) );

                    $this->setResponse( $this->$action( $request, $logger, $doctrine, $passwordHasher, true ) ); // ACTION
                    if ( $this->getError() ) {
                        $code = 206;
                        $error = true;
                        $data['messages'][] = $this->getMessage();
                    } else {
                        $message = 'Actions exec in ' . __FUNCTION__;
                    }
                    [ $actionResult['code'], $actionResult['error'], $actionResult['message'], $actionResult['data'], $actionResult['object']
                    ] = $this->getResponse('unstructure');
                    $object[] = $actionResult;
                }

            } else { [$code, $error, $message, $data, $object] = $this->getResponse('unstructure'); }

            // Set Response
            $this->finalResponse( $code, $error, $message, $data, $object );

            // debug
            $typeOfDebug = ( $code == 200 ) ? 'info' : 'warning';
            $logger->$typeOfDebug( json_encode( [__FUNCTION__ => $this->getResponse()] ) );
            $logger->info( 'Init method ' . __FUNCTION__ );

        } catch (Exception $ex) {
            $this->setCode(418);
            $this->setError(true);
            $this->setMessage("Error: {$ex->getMessage()} in class: " . __CLASS__.", method: " . __FUNCTION__ . ", file: " . __FILE__ . ", line: " . __LINE__);
        }
        if ( $returnArray ) { return $this->getResponse(); }
        else { return $this->doJsonResponse(); }
    }

    /** Example method to create an user with request params.
     * This method will be a example to create a controller endpoint for actions in app.
     * You must send the params required and the format correct to create an user.
     * 
     * @OA\Tag(name="Test")
     * @Route("/test/createUserRequest", name="test_createUserRequest", methods={"POST"})
     * @IsGranted("ROLE_STANDARD", message="You dont have permissions to do this action", statusCode=401)
     * @OA\Response( response="default", description="An 'unexpected' error." )
     *
     * @OA\Parameter( in="header", name="authorization", required=true, description="passing JWT from headers" )
     *
     * @OA\Parameter(name="_username", in="query", required=true, description="The param username")
     * @OA\Parameter(name="_password", in="query", required=false, description="The param password")
     * @OA\Parameter(name="_name", in="query", required=false, description="The param name")
     * @OA\Parameter(name="_email", in="query", required=false, description="The param email")
     */
    public function createUserRequest(Request $request, LoggerInterface $logger, ManagerRegistry $doctrine, UserPasswordHasherInterface $passwordHasher, Bool $returnArray = false) {
        try {
            $code = 400; $error = true; $message = 'No get params to do action in ' . __FUNCTION__; $data = []; $object = [];
            $this->initializeResponse( $code, $error, $message );
            if ( ! $returnArray ) {  $request = ProcessRequest::processRequest($request); }
            $entityManager = $doctrine->getManager();
            $logger->info( 'Init method ' . __FUNCTION__ );

            // debug get request
            $data['request'] = $request->request->all();

            // required params
            $processRequest = new ProcessRequest( $entityManager, $logger );
            $this->setResponse( $processRequest->requiredParams($request, ['_username', '_plainPassword', '_email', '_name']) );
            if ( !$this->getError() ) {

                // your code
                $now = new Datetime('now');

                // init modelCRUD
                $userCRUD = new UserCRUD($doctrine, $logger);
                $userCRUD->initCRUD( $passwordHasher ); // special for user because we have to has the password
                
                // password
                if ( $request->request->has('_plainPassword') ) {
                    $passToBBDD = $passwordHasher->hashPassword(
                        $userCRUD->getModel(),
                        $request->request->get('_plainPassword')
                    );
                    $request->request->set('_password', $passToBBDD);
                }

                $this->setResponse( $userCRUD->create( $request, null, null) );
                [$code, $error, $message, $data, $object] = $this->getResponse('unstructure');
                if ( !$this->getError() ) {

                    $userSerialized = $userCRUD->normalizeObjectFull( $this->getObject(), 2 );
                    $object = $userSerialized;

                } // else { [$code, $error, $message, $data, $object] = $this->getResponse('unstructure'); }
            } else { [$code, $error, $message, $data, $object] = $this->getResponse('unstructure'); }

            // Set Response
            $this->finalResponse( $code, $error, $message, $data, $object );

            // debug
            $typeOfDebug = ( $code == 200 ) ? 'info' : 'warning';
            $logger->$typeOfDebug( json_encode( [__FUNCTION__ => $this->getResponse()] ) );
            $logger->info( 'Init method ' . __FUNCTION__ );

        } catch (Exception $ex) {
            $this->setCode(418);
            $this->setError(true);
            $this->setMessage("Error: {$ex->getMessage()} in class: " . __CLASS__.", method: " . __FUNCTION__ . ", file: " . __FILE__ . ", line: " . __LINE__);
        }
        if ( $returnArray ) { return $this->getResponse(); }
        else { return $this->doJsonResponse(); }
    }

    /** Example method to update an user with request params.
     * This method will be a example to update a controller endpoint for actions in app.
     * You must send the params required and the format correct to update an user.
     * 
     * @OA\Tag(name="Test")
     * @Route("/test/updateUserRequest", name="test_updateUserRequest", methods={"POST"})
     * @IsGranted("ROLE_STANDARD", message="You dont have permissions to do this action", statusCode=401)
     * @OA\Response( response="default", description="An 'unexpected' error." )
     *
     * @OA\Parameter( in="header", name="authorization", required=true, description="passing JWT from headers" )
     *
     * @OA\Parameter(name="_username", in="query", required=true, description="The param username")
     * @OA\Parameter(name="_password", in="query", required=false, description="The param password")
     * @OA\Parameter(name="_name", in="query", required=false, description="The param name")
     * @OA\Parameter(name="_email", in="query", required=false, description="The param email")
     */
    public function updateUserRequest(Request $request, LoggerInterface $logger, ManagerRegistry $doctrine, UserPasswordHasherInterface $passwordHasher, Bool $returnArray = false) {
        try {
            $code = 400; $error = true; $message = 'No get params to do action in ' . __FUNCTION__; $data = []; $object = [];
            $this->initializeResponse( $code, $error, $message );
            if ( ! $returnArray ) {  $request = ProcessRequest::processRequest($request); }
            $entityManager = $doctrine->getManager();
            $logger->info( 'Init method ' . __FUNCTION__ );

            // debug get request
            $data['request'] = $request->request->all();

            // required params
            $processRequest = new ProcessRequest( $entityManager, $logger );
            $this->setResponse( $processRequest->requiredParams($request, ['_username' => '_id', '_email' => '_id']) );
            if ( !$this->getError() ) {

                // your code
                $userCRUD = new UserCRUD($doctrine, $logger, $this->getUser());
                $userCRUD->initCRUD( $passwordHasher ); // special for user because we have to has the password

                // password
                if ( $request->request->has('_plainPassword') ) {
                    $passToBBDD = $passwordHasher->hashPassword(
                        $userCRUD->getModel(),
                        $request->request->get('_plainPassword')
                    );
                    $request->request->set('_password', $passToBBDD);
                }

                $userToUpdate = null;
                if ( $request->request->has('_id') ) {
                    $userToUpdate = $entityManager->getRepository('App\Entity\User')->findOneBy( ['id' => $request->request->get('_id')] );
                    if ( $userToUpdate != null ) {
                        $userCRUD->setRequiredParams([]);
                    }
                }

                // init modelCRUD
                // $userCRUD->setThisUser( $this->getUser() );
                $this->setResponse( $userCRUD->update( $request, null, $userToUpdate) );
                [$code, $error, $message, $data, $object] = $this->getResponse('unstructure');
                if ( !$this->getError() ) {

                    $userSerialized = $userCRUD->normalizeObjectFull( $this->getObject(), 2 );
                    $object = $userSerialized;

                } // else { [$code, $error, $message, $data, $object] = $this->getResponse('unstructure'); }
            } else { [$code, $error, $message, $data, $object] = $this->getResponse('unstructure'); }

            // Set Response
            $this->finalResponse( $code, $error, $message, $data, $object );

            // debug
            $typeOfDebug = ( $code == 200 ) ? 'info' : 'warning';
            $logger->$typeOfDebug( json_encode( [__FUNCTION__ => $this->getResponse()] ) );
            $logger->info( 'Init method ' . __FUNCTION__ );

        } catch (Exception $ex) {
            $this->setCode(418);
            $this->setError(true);
            $this->setMessage("Error: {$ex->getMessage()} in class: " . __CLASS__.", method: " . __FUNCTION__ . ", file: " . __FILE__ . ", line: " . __LINE__);
        }
        if ( $returnArray ) { return $this->getResponse(); }
        else { return $this->doJsonResponse(); }
    }

    /** Example method to do a controller endpoint.
     * This method will be a example to create a controller endpoint for actions in app.
     * You musn´t send a JWT to do actions of the method. This method may be declared in the security.yml with no perission
     * 
     * @OA\Tag(name="Test")
     * @Route("/test/exampleWithOutPermissions", name="test_exampleWithOutPermissions", methods={"POST"})
     * @OA\Response( response="default", description="An 'unexpected' error." )
     *
     * @OA\Parameter(name="_param1", in="query", form="true", required=true, description="The param 1")
     * @OA\Parameter(name="_param2", in="query", form="true", required=false, description="The param 2")
     */
    public function exampleWithOutPermissions(Request $request, LoggerInterface $logger, ManagerRegistry $doctrine, Bool $returnArray = false) {
        try {
            $code = 400; $error = true; $message = 'No get params to do action in ' . __FUNCTION__; $data = []; $object = [];
            $this->initializeResponse( $code, $error, $message );
            if ( ! $returnArray ) {  $request = ProcessRequest::processRequest($request); }
            $entityManager = $doctrine->getManager();
            $logger->info( 'Init method ' . __FUNCTION__ );

            // debug get request
            $data['request'] = $request->request->all();

            // required params
            $processRequest = new ProcessRequest( $entityManager, $logger );
            $this->setResponse( $processRequest->requiredParams($request, ['_param1']) );
            if ( !$this->getError() ) {

                // your code
                [$code, $error, $message] = [200, false, 'You use this method correct'];

            } else { [$code, $error, $message, $data, $object] = $this->getResponse('unstructure'); }

            // Set Response
            $this->finalResponse( $code, $error, $message, $data, $object );

            // debug
            $typeOfDebug = ( $code == 200 ) ? 'info' : 'warning';
            $logger->$typeOfDebug( json_encode( [__FUNCTION__ => $this->getResponse()] ) );
            $logger->info( 'Init method ' . __FUNCTION__ );

        } catch (Exception $ex) {
            $this->setCode(418);
            $this->setError(true);
            $this->setMessage("Error: {$ex->getMessage()} in class: " . __CLASS__.", method: " . __FUNCTION__ . ", file: " . __FILE__ . ", line: " . __LINE__);
        }
        if ( $returnArray ) { return $this->getResponse(); }
        else { return $this->doJsonResponse(); }
    }

    /** Example method to do a controller endpoint.
     * This method will be a example to create a controller endpoint for actions in app.
     * You must send a correct JWT of user with enought permission to do actions of the method.
     * 
     * @OA\Tag(name="Test")
     * @Route("/test/exampleWithPermissions", name="test_exampleWithPermissions", methods={"POST"})
     * @IsGranted("ROLE_STANDARD", message="You dont have permissions to do this action", statusCode=401)
     * @OA\Response( response="default", description="An 'unexpected' error." )
     *
     * @OA\Parameter( in="header", name="authorization", required=true, description="passing JWT from headers" )
     *
     * @OA\Parameter(name="_param1", in="query", required=true, description="The param 1")
     * @OA\Parameter(name="_param2", in="query", required=false, description="The param 2")
     */
    public function exampleWithPermissions(Request $request, LoggerInterface $logger, ManagerRegistry $doctrine, Bool $returnArray = false) {
        try {
            $code = 400; $error = true; $message = 'No get params to do action in ' . __FUNCTION__; $data = []; $object = [];
            $this->initializeResponse( $code, $error, $message );
            if ( ! $returnArray ) {  $request = ProcessRequest::processRequest($request); }
            $entityManager = $doctrine->getManager();
            $logger->info( 'Init method ' . __FUNCTION__ );

            // debug get request
            $data['request'] = $request->request->all();

            // required params
            $processRequest = new ProcessRequest( $entityManager, $logger );
            $this->setResponse( $processRequest->requiredParams($request, ['_param1']) );
            if ( !$this->getError() ) {

                // your code
                [$code, $error, $message] = [200, false, 'You use this method correct'];

            } else { [$code, $error, $message, $data, $object] = $this->getResponse('unstructure'); }

            // Set Response
            $this->finalResponse( $code, $error, $message, $data, $object );

            // debug
            $typeOfDebug = ( $code == 200 ) ? 'info' : 'warning';
            $logger->$typeOfDebug( json_encode( [__FUNCTION__ => $this->getResponse()] ) );
            $logger->info( 'Init method ' . __FUNCTION__ );

        } catch (Exception $ex) {
            $this->setCode(418);
            $this->setError(true);
            $this->setMessage("Error: {$ex->getMessage()} in class: " . __CLASS__.", method: " . __FUNCTION__ . ", file: " . __FILE__ . ", line: " . __LINE__);
        }
        if ( $returnArray ) { return $this->getResponse(); }
        else { return $this->doJsonResponse(); }
    }

    /**
     * DEPRECATED
     */
}