<?php

namespace App\Service\Utilities;

use Symfony\Component\Config\Definition\Exception\Exception;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Component\HttpFoundation\Request;

use App\Model\Traits\TraitResponse;
use Psr\Log\LoggerInterface;

/**
 *  
 * @author DigitalVirgo España
 */
class ProcessRequest
{
    // Respuesta estandar
    use TraitResponse;
    
    protected $doctrine;
    protected $entityManager;
    protected $logger;
    protected $containerInterface;

    /** Contructor of the class */
    public function __construct($entityManager, LoggerInterface $logger = null) {
        $this->doctrine = ( !$entityManager instanceof EntityManagerInterface ) ? $entityManager : null;
        $this->entityManager = ( $entityManager instanceof EntityManagerInterface ) ? $entityManager : $this->doctrine->getManager();
        $this->logger = $logger;
        $this->containerInterface = null;
    }

    /** Contructor0 of the class OLD_method */
    public function __construct0($entityManager, ContainerInterface $containerInterface = null) {
        $this->doctrine = ( !$entityManager instanceof EntityManagerInterface ) ? $entityManager : null;
        $this->entityManager = ( $entityManager instanceof EntityManagerInterface ) ? $entityManager : $this->doctrine->getManager();
        $this->containerInterface = $containerInterface;
        $this->logger = null;
    }
    /** Contructor of the class */
    // public function __construct(Request $request) {
    //     return $this->processRequest($request);
    // }
    
    /**
     * *************************
     * *** Generic functions ***
     * *************************
     */

    /** 
     * Required general 
     * Process required params to process endpoints
    */
    public function requiredGeneralParams(Request $request, Array $paramsRequired = array()): Array {
        try { $this->initializeResponse(403, false);
            if ( count($paramsRequired) >= 1 ) {                
                foreach ($paramsRequired as $key => $value) {
                    if ( !$request->request->has($key) ){
                        if ( !$request->request->has($value) ){
                            $this->setError(true);
                            $this->setMessage( (getType($key) != 'string' || $key == $value) ? 'No property ' . $value . ' received'
                                                                : 'No properties ' . $key . ' or ' . $value . ' received' );
                            $this->setMessage( $this->getMessage() . ' in class: ' . __CLASS__. ', method: ' . __FUNCTION__ );
                        }
                    }
                }
            } else { $this->setError(true); $this->setMessage('No get params for validate required'); }
        } catch (Exception $ex) {
            $this->setCode(500);
            $this->setError(true);
            $this->setMessage("Error: {$ex->getMessage()} in class: " . __CLASS__.
            ", method: " . __FUNCTION__ . ", file: " . __FILE__ . ", line: " . __LINE__);
        } return $this->getResponse();
    }

    /** for clean name  requiredGeneralParams */
    public function requiredParams(Request $request, Array $paramsRequired = []): Array {
        try { 
            
            $this->setResponse( $this->requiredGeneralParams($request, $paramsRequired) );     

        } catch (Exception $ex) {
            $this->setCode(500);
            $this->setError(true);
            $this->setMessage("Error: {$ex->getMessage()} in class: " . __CLASS__.
            ", method: " . __FUNCTION__ . ", file: " . __FILE__ . ", line: " . __LINE__);
        } return $this->getResponse();
    }
    
    /**
     * **********************
     * *** STATIC METHODS ***
     * **********************
     */

    /**
     * We have to process request to get the params receibed in all formats, params from form or params in body (json)
     */
    static function processRequest(Request $request, TraitResponse $traitResponse = null) {
        try { // $this->initializeResponse(403, false);
            if ( $request->getContent() ) {
                $data = json_decode($request->getContent(), TRUE);
                if ( is_array($data) && count($data) >= 1 ) {
                    foreach ($data as $key => $value) {
                        $request->request->set($key, $value);
                    }
                }
            }
        } catch (Exception $ex) {
            $traitResponse->setCode(500);
            $traitResponse->setError(true);
            $traitResponse->setMessage("Error: {$ex->getMessage()} in class: " . __CLASS__.
            ", method: " . __FUNCTION__ . ", file: " . __FILE__ . ", line: " . __LINE__);
            return $traitResponse->getResponse();
        }
        return $request;
        //return $this->getResponse();
    }
    
    /**
     * **********************
     * ***   DEPRECATED   ***                       
     * **********************
     */

}